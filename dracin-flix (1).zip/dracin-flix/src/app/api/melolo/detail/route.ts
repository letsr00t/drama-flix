import { NextRequest } from "next/server";
import { encryptedResponse } from "@/lib/api-utils";

export const dynamic = 'force-dynamic';

const MELOLO_HEADERS = {
  "Accept": "application/json; charset=utf-8,application/x-protobuf",
  "Accept-Encoding": "gzip, deflate",
  "x-xs-from-web": "false",
  "age-range": "8",
};

export async function GET(request: NextRequest) {
  const searchParams = request.nextUrl.searchParams;
  const bookId = searchParams.get("bookId");

  if (!bookId) {
    return encryptedResponse({ error: "Missing bookId" }, 400);
  }

  try {
    const url = "https://api.tmtreader.com/novel/player/video_detail/v1/?iid=7604173033750415125&device_id=7554232785717380664&ac=mobile&channel=gp&aid=645713&app_name=Melolo&version_code=51617&version_name=5.1.6&device_platform=android&os=android&ssmix=a&device_type=SM-A042F&device_brand=samsung&language=in&os_api=33&os_version=13&openudid=d7ad3f25422073a0&manifest_version_code=51617&resolution=720*1465&dpi=300&update_version_code=51617&_rticket=1770486349961&current_region=ID&carrier_region=id&app_language=id&sys_language=in&app_region=ID&prefer_gd=0&sys_region=ID&mcc_mnc=51001&carrier_region_v2=510&user_language=id&time_zone=Asia%2FMakassar&ui_language=in&cdid=245817c0-0db2-4417-9483-e535ug421t12";

    const body = {
      biz_param: {
        detail_page_version: 0,
        from_video_id: "",
        need_all_video_definition: false,
        need_mp4_align: false,
        source: 4,
        use_os_player: false,
        video_id_type: 1,
      },
      series_id: bookId,
    };

    const response = await fetch(url, {
      method: "POST",
      headers: { ...MELOLO_HEADERS, "Content-Type": "application/json" },
      body: JSON.stringify(body),
      cache: 'no-store',
    });
    const data = await response.json();
    return encryptedResponse(data);
  } catch (error) {
    console.error("Error fetching Melolo detail:", error);
    return encryptedResponse({ error: "Failed to fetch data" }, 500);
  }
}
