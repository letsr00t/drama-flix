import { encryptedResponse } from "@/lib/api-utils";
import { NextRequest } from "next/server";

export const dynamic = 'force-dynamic';

const MELOLO_HEADERS = {
  "User-Agent": "com.worldance.drama/49819 (Linux; U; Android 13; in; SM-A042F; Build/TP1A.220624.014; Cronet/TTNetVersion:8f366453 2024-12-24 QuicVersion:ef6c341e 2024-11-14)",
  "Accept": "application/json; charset=utf-8,application/x-protobuf",
  "Accept-Encoding": "gzip, deflate",
  "x-xs-from-web": "false",
  "age-range": "8",
};

export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams;
    const offset = searchParams.get("offset") || "0";

    const url = `https://api.tmtreader.com/i18n_novel/bookmall/cell/change/v1/?max_abstract_len=0&selected_tag_id=-1&selected_tag_type=2&offset=${offset}&is_preload=false&recommend_enable_write_client_session_cache_only=false&preference_strategy=0&session_id=202602080139170E88047C6763DB9510C5&change_type=0&enable_new_show_mechanism=false&time_zone=Asia%2FMakassar&is_preference_force_insert=false&is_landing_page=0&tab_scene=3&tab_type=0&limit=10&preference_list&start_offset=0&cell_id=7450059162446200848&iid=7604173033750415125&device_id=7554232785717380664&ac=mobile&channel=gp&aid=645713&app_name=Melolo&version_code=51617&version_name=5.1.6&device_platform=android&os=android&ssmix=a&device_type=SM-A042F&device_brand=samsung&language=in&os_api=33&os_version=13&openudid=d7ad3f25422073a0&manifest_version_code=51617&resolution=720*1465&dpi=300&update_version_code=51617&_rticket=1770485967553&current_region=ID&carrier_region=id&app_language=id&sys_language=in&app_region=ID&prefer_gd=0&sys_region=ID&mcc_mnc=51001&carrier_region_v2=510&user_language=id&ui_language=in&cdid=245817c0-0db2-4417-9483-e535ug421t12`;

    const response = await fetch(url, {
      headers: MELOLO_HEADERS,
      cache: 'no-store',
    });

    if (!response.ok) {
      return encryptedResponse({ books: [], has_more: false, next_offset: 0 });
    }

    const json = await response.json();
    const data = json.data;

    let books: any[] = [];

    if (data?.cell?.cell_data && Array.isArray(data.cell.cell_data)) {
      data.cell.cell_data.forEach((section: any) => {
        if (section.books && Array.isArray(section.books)) {
          books = [...books, ...section.books];
        }
      });
    }
    if (data?.cell?.books && Array.isArray(data.cell.books)) {
      books = [...books, ...data.cell.books];
    }
    if (data?.books && Array.isArray(data.books)) {
      books = [...books, ...data.books];
    }

    const hasMore = data?.has_more ?? data?.cell?.has_more ?? false;
    const nextOffset = data?.next_offset ?? data?.cell?.next_offset ?? 0;

    return encryptedResponse({ books, has_more: hasMore, next_offset: nextOffset });
  } catch (error) {
    console.error("Melolo ForYou Error:", error);
    return encryptedResponse({ books: [], has_more: false, next_offset: 0 });
  }
}
