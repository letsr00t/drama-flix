# 🎬 DramaFlix - Drama Streaming Platform

A Netflix-style streaming platform for short dramas with multi-provider support (MeloLo & DramaBox).

## ✨ Features

### Backend
- 🔄 Multi-provider system (MeloLo, DramaBox)
- 💾 Intelligent caching layer
- ⚡ Request queue & rate limiting
- 🛡️ CORS & security middleware
- 📊 RESTful API with 8 endpoints
- 🔍 Search functionality
- 📺 Video streaming support

### Frontend
- 🎨 Netflix-inspired UI/UX
- 📱 Fully responsive design
- 🎯 Hero banner with featured content
- 📜 Horizontal scrolling carousels
- 🔍 Real-time search
- 📹 Built-in video player
- ⚡ Fast page transitions
- 💫 Smooth animations

## 🚀 Quick Start

### Prerequisites
- Node.js 16.x or higher
- npm or yarn

### Installation

#### 1. Clone the repository
```bash
git clone <repository-url>
cd drama-app
```

#### 2. Backend Setup

```bash
# Navigate to backend
cd backend

# Install dependencies
npm install

# Create .env file
cp .env.example .env

# Start backend server
npm start
```

Backend will run on `http://localhost:5000`

#### 3. Frontend Setup

```bash
# Open new terminal
cd frontend

# Install dependencies
npm install

# Start development server
npm run dev
```

Frontend will run on `http://localhost:3000`

## 📁 Project Structure

```
drama-app/
├── backend/
│   ├── src/
│   │   ├── providers/      # Platform providers
│   │   ├── services/       # Business logic
│   │   ├── routes/         # API routes
│   │   ├── middlewares/    # Express middlewares
│   │   ├── utils/          # Helper utilities
│   │   └── app.js          # Main application
│   ├── package.json
│   └── .env.example
│
└── frontend/
    ├── src/
    │   ├── components/     # React components
    │   ├── pages/          # Page components
    │   ├── services/       # API services
    │   ├── styles/         # Global styles
    │   ├── App.jsx         # Main App component
    │   └── main.jsx        # Entry point
    ├── package.json
    └── vite.config.js
```

## 🔌 API Endpoints

### Base URL: `http://localhost:5000/api`

#### General
- `GET /health` - Health check
- `GET /providers` - Get available providers
- `GET /stats` - System statistics

#### Drama Endpoints
- `GET /:provider/home` - Home page content
- `GET /:provider/foryou?page=1` - For You feed
- `GET /:provider/trending` - Trending dramas
- `GET /:provider/latest` - Latest releases
- `GET /:provider/search?query=keyword` - Search dramas
- `GET /:provider/detail/:id` - Drama details
- `GET /:provider/episodes/:id` - Episode list
- `GET /:provider/watch/:videoId` - Stream URL

### Example Requests

```bash
# Get home content from MeloLo
curl http://localhost:5000/api/melolo/home

# Search for dramas
curl http://localhost:5000/api/melolo/search?query=love

# Get drama detail
curl http://localhost:5000/api/melolo/detail/7583531888644459525
```

## 🎨 Frontend Routes

- `/` - Home page with featured content
- `/search?q=keyword` - Search results
- `/detail/:provider/:id` - Drama detail page
- `/watch/:provider/:dramaId/:videoId` - Video player

## ⚙️ Configuration

### Backend (.env)

```env
PORT=5000
NODE_ENV=development
ALLOWED_ORIGINS=http://localhost:3000,http://localhost:5173
CACHE_TTL=3600
RATE_LIMIT_MAX_REQUESTS=100
```

### Frontend

API proxy is configured in `vite.config.js`:
```javascript
proxy: {
  '/api': {
    target: 'http://localhost:5000',
    changeOrigin: true
  }
}
```

## 🔧 Development

### Backend Development

```bash
cd backend

# Start with auto-reload
npm run dev

# Or use nodemon
npm install -g nodemon
nodemon src/app.js
```

### Frontend Development

```bash
cd frontend

# Start dev server
npm run dev

# Build for production
npm run build

# Preview production build
npm run preview
```

## 🎯 Features Breakdown

### Provider System
- **BaseProvider**: Abstract class for all providers
- **MeloLoProvider**: Fully implemented with all endpoints
- **DramaBoxProvider**: Template implementation (needs API verification)

### Caching System
- In-memory cache using node-cache
- Configurable TTL per endpoint
- Cache statistics tracking
- Hit rate monitoring

### Rate Limiting
- Request queue with configurable concurrency
- Automatic delays between requests
- Prevents API throttling

### Error Handling
- Comprehensive error middleware
- Axios error parsing
- User-friendly error messages
- Automatic retry logic

## 📱 Responsive Design

Breakpoints:
- Desktop: 1024px+
- Tablet: 768px - 1023px
- Mobile: 480px - 767px
- Small Mobile: < 480px

## 🎬 Screenshots

### Home Page
- Hero banner with featured drama
- Trending dramas carousel
- For You recommendations
- Latest releases

### Detail Page
- Full drama information
- Episode grid with thumbnails
- Play/Lock status indicators

### Search Page
- Real-time search results
- Grid layout
- Empty state handling

### Watch Page
- Full-screen video player
- Quality indicators
- Back navigation

## ⚠️ Important Notes

### Legal & Ethical Use
- ✅ Access only FREE content
- ❌ Do NOT bypass paywalls
- ❌ Do NOT access premium content without authorization
- ✅ Respect rate limits
- ✅ Educational/personal use only

### API Limitations
- MeloLo: Fully functional
- DramaBox: Placeholder (needs actual API endpoints)
- Rate limits enforced on both client and server
- Cache to reduce redundant requests

## 🐛 Troubleshooting

### Backend not starting
```bash
# Check if port 5000 is available
lsof -i :5000

# Install dependencies again
rm -rf node_modules package-lock.json
npm install
```

### Frontend not connecting to backend
```bash
# Verify backend is running
curl http://localhost:5000/api/health

# Check proxy configuration in vite.config.js
# Ensure CORS is properly configured in backend
```

### Videos not playing
- Check if episode is locked (premium)
- Verify stream URL is valid
- Check browser console for errors
- Some videos may require authentication

## 📝 License

This project is for educational purposes only.

## 🤝 Contributing

This is a demonstration project. For production use:
1. Implement proper authentication
2. Add database for user management
3. Implement proper DRM if needed
4. Add analytics tracking
5. Optimize performance
6. Add comprehensive tests

## 📧 Support

For issues or questions, please check:
1. Backend logs in terminal
2. Frontend console in browser
3. Network tab for API calls
4. README troubleshooting section

---

**Built with ❤️ using React, Express, and modern web technologies**
