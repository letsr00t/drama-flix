# 🚀 QUICK START GUIDE - DramaFlix

## ⚠️ IMPORTANT - READ THIS FIRST!

Jika Anda mendapat error `Cannot find package 'express'` atau sejenisnya, 
itu karena **dependencies belum di-install**.

---

## ✅ LANGKAH-LANGKAH SETUP (5 MENIT)

### Step 1️⃣: Extract ZIP File
```bash
unzip drama-app.zip
cd drama-app
```

### Step 2️⃣: Install Backend Dependencies
```bash
cd backend
npm install
```

**Tunggu sampai selesai!** Ini akan download:
- express
- axios  
- cors
- dotenv
- express-rate-limit
- node-cache

**Total size:** ~20 MB

### Step 3️⃣: Install Frontend Dependencies
```bash
cd ../frontend
npm install
```

**Tunggu sampai selesai!** Ini akan download:
- react
- react-dom
- react-router-dom
- axios
- vite
- lucide-react

**Total size:** ~130 MB

### Step 4️⃣: Start Backend
```bash
cd ../backend
npm start
```

Anda akan melihat:
```
╔══════════════════════════════════════════╗
║   🎬  Drama Streaming API Server  🎬    ║
╠══════════════════════════════════════════╣
║  Status: Running                         ║
║  Port: 5000                              ║
╚══════════════════════════════════════════╝
```

**Jangan tutup terminal ini!** ✋

### Step 5️⃣: Start Frontend (Terminal Baru)
```bash
# Buka terminal/command prompt BARU
cd drama-app/frontend
npm run dev
```

Anda akan melihat:
```
  VITE v5.0.8  ready in 500 ms

  ➜  Local:   http://localhost:3000/
  ➜  Network: use --host to expose
  ➜  press h + enter to show help
```

### Step 6️⃣: Buka Browser
```
http://localhost:3000
```

**🎉 DONE! Aplikasi sudah berjalan!**

---

## 🐛 TROUBLESHOOTING

### Error: `Cannot find package 'express'`
**Solusi:**
```bash
cd backend
rm -rf node_modules package-lock.json
npm install
```

### Error: `Cannot find package 'react'`
**Solusi:**
```bash
cd frontend
rm -rf node_modules package-lock.json
npm install
```

### Error: `Port 5000 already in use`
**Solusi:**
```bash
# Edit backend/.env
# Ubah PORT=5000 menjadi PORT=5001
```

### Error: `Port 3000 already in use`
**Solusi:**
```bash
# Frontend akan auto-detect dan gunakan port lain (3001, 3002, etc)
# Atau kill process:
# Windows: netstat -ano | findstr :3000
# Linux/Mac: lsof -ti:3000 | xargs kill
```

### Backend running tapi tidak ada response
**Cek:**
```bash
curl http://localhost:5000/api/health

# Harus return:
# {"success":true,"data":{"status":"OK"}}
```

### Frontend tidak bisa connect ke backend
**Solusi:**
1. Pastikan backend running di port 5000
2. Cek vite.config.js proxy settings
3. Cek backend CORS settings di .env

---

## 📋 CHECKLIST SEBELUM MULAI

- [ ] Node.js 16+ installed (`node --version`)
- [ ] npm installed (`npm --version`)
- [ ] ZIP file di-extract
- [ ] Terminal/Command Prompt siap
- [ ] Internet connection (untuk npm install)

---

## 🎯 COMMANDS CHEAT SHEET

### Backend:
```bash
# Install
cd backend && npm install

# Start development
npm start

# Check if running
curl http://localhost:5000/api/health
```

### Frontend:
```bash
# Install
cd frontend && npm install

# Start development
npm run dev

# Build for production
npm run build
```

### Both (Easy Start):
```bash
# Linux/Mac
chmod +x start.sh
./start.sh

# Windows
start.bat
```

---

## 📁 STRUKTUR SETELAH NPM INSTALL

```
drama-app/
├── backend/
│   ├── node_modules/     ← Created after npm install (~20 MB)
│   ├── package.json
│   ├── .env
│   └── src/
│
├── frontend/
│   ├── node_modules/     ← Created after npm install (~130 MB)
│   ├── package.json
│   └── src/
│
└── README.md
```

---

## ⚡ FASTEST SETUP (Copy-Paste)

**Untuk Linux/Mac:**
```bash
# Extract & Setup
unzip drama-app.zip
cd drama-app

# Install all dependencies
cd backend && npm install && cd ..
cd frontend && npm install && cd ..

# Start (in one command)
chmod +x start.sh && ./start.sh
```

**Untuk Windows (PowerShell):**
```powershell
# Extract & Setup
Expand-Archive drama-app.zip
cd drama-app

# Install all dependencies
cd backend; npm install; cd ..
cd frontend; npm install; cd ..

# Start
.\start.bat
```

---

## 🔍 VERIFY INSTALLATION

### Check Node & npm:
```bash
node --version   # Should be v16+
npm --version    # Should be v8+
```

### Check Backend Dependencies:
```bash
cd backend
npm list --depth=0

# Should show:
# ├── axios@1.6.0
# ├── cors@2.8.5
# ├── dotenv@16.3.1
# ├── express@4.18.2
# ├── express-rate-limit@7.1.5
# └── node-cache@5.1.2
```

### Check Frontend Dependencies:
```bash
cd frontend
npm list --depth=0

# Should show:
# ├── axios@1.6.0
# ├── lucide-react@0.294.0
# ├── react@18.2.0
# ├── react-dom@18.2.0
# ├── react-router-dom@6.20.0
# └── vite@5.0.8
```

---

## 🎬 FIRST TIME RUNNING

### What to expect:

**Backend Console:**
```
Server berjalan di http://localhost:5000
Dokumentasi tersedia di http://localhost:5000
```

**Frontend Console:**
```
VITE v5.0.8  ready in 500 ms
➜  Local:   http://localhost:3000/
```

**Browser (http://localhost:3000):**
- ✅ Netflix-style interface
- ✅ Hero banner with featured drama
- ✅ Horizontal scrolling rows
- ✅ Search bar in navbar
- ✅ Responsive design

---

## 📞 NEED HELP?

### Common Issues:

1. **"Command not found: npm"**
   - Install Node.js from https://nodejs.org/

2. **"EACCES permission error"**
   - Don't use sudo! Fix npm permissions:
   ```bash
   mkdir ~/.npm-global
   npm config set prefix '~/.npm-global'
   export PATH=~/.npm-global/bin:$PATH
   ```

3. **"Network error during npm install"**
   - Check internet connection
   - Try: `npm install --registry=https://registry.npmjs.org/`

4. **"Module not found after install"**
   - Clear cache: `npm cache clean --force`
   - Delete node_modules and reinstall

---

## 🎯 NEXT STEPS AFTER SETUP

1. ✅ Explore the app at http://localhost:3000
2. ✅ Try searching for dramas
3. ✅ Click on a drama to see details
4. ✅ Play a free episode
5. ✅ Read API.md to understand the backend
6. ✅ Read DEPLOYMENT.md to deploy online

---

## 💡 PRO TIPS

### Development Mode:
- Backend auto-restarts on code changes (if using nodemon)
- Frontend has hot-reload (Vite HMR)
- Check console for errors

### Production Build:
```bash
# Frontend
cd frontend
npm run build
# Creates optimized bundle in dist/

# Deploy dist/ folder to hosting
```

### Environment Variables:
```bash
# Backend (.env)
PORT=5000
NODE_ENV=development
ALLOWED_ORIGINS=http://localhost:3000

# Frontend (create .env)
VITE_API_URL=http://localhost:5000/api
```

---

## ✅ INSTALLATION COMPLETE CHECKLIST

- [ ] Node.js installed
- [ ] ZIP extracted
- [ ] Backend dependencies installed (`npm install` in backend/)
- [ ] Frontend dependencies installed (`npm install` in frontend/)
- [ ] Backend running (http://localhost:5000)
- [ ] Frontend running (http://localhost:3000)
- [ ] App opens in browser
- [ ] No console errors

**If all checked ✅ - You're ready to go! 🚀**

---

## 📖 DOCUMENTATION

- `README.md` - Main documentation
- `API.md` - API reference
- `DEPLOYMENT.md` - Deployment guide
- `TESTING.md` - Testing guide
- `CONTRIBUTING.md` - How to contribute

---

**Made with ❤️ for drama lovers**

*Happy Streaming! 🎬*
