// src/components/DramaRow.jsx
import { useRef } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import DramaCard from './DramaCard';
import './DramaRow.css';

function DramaRow({ title, dramas }) {
  const rowRef = useRef(null);

  const scroll = (direction) => {
    if (rowRef.current) {
      const scrollAmount = direction === 'left' ? -800 : 800;
      rowRef.current.scrollBy({ left: scrollAmount, behavior: 'smooth' });
    }
  };

  if (!dramas || dramas.length === 0) {
    return null;
  }

  return (
    <div className="drama-row">
      <h2 className="row-title">{title}</h2>
      <div className="row-container">
        <button
          className="scroll-button left"
          onClick={() => scroll('left')}
          aria-label="Scroll left"
        >
          <ChevronLeft size={32} />
        </button>

        <div className="row-content" ref={rowRef}>
          {dramas.map((drama, index) => (
            <div key={`${drama.id}-${index}`} className="row-item">
              <DramaCard drama={drama} />
            </div>
          ))}
        </div>

        <button
          className="scroll-button right"
          onClick={() => scroll('right')}
          aria-label="Scroll right"
        >
          <ChevronRight size={32} />
        </button>
      </div>
    </div>
  );
}

export default DramaRow;
