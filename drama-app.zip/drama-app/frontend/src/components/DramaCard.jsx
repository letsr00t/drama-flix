// src/components/DramaCard.jsx
import { useNavigate } from 'react-router-dom';
import { Play, Info } from 'lucide-react';
import './DramaCard.css';

function DramaCard({ drama }) {
  const navigate = useNavigate();

  const handleClick = () => {
    navigate(`/detail/${drama.provider}/${drama.id}`);
  };

  return (
    <div className="drama-card" onClick={handleClick}>
      <div className="drama-card-image">
        <img
          src={drama.cover}
          alt={drama.title}
          loading="lazy"
          onError={(e) => {
            e.target.src = 'https://via.placeholder.com/300x450?text=No+Image';
          }}
        />
        <div className="drama-card-overlay">
          <div className="overlay-content">
            <button className="play-button">
              <Play size={20} fill="white" />
              <span>Play</span>
            </button>
            <button className="info-button">
              <Info size={18} />
            </button>
          </div>
        </div>
      </div>
      <div className="drama-card-info">
        <h3 className="drama-title">{drama.title}</h3>
        <div className="drama-meta">
          {drama.episodeCount && (
            <span className="episode-count">{drama.episodeCount} Episodes</span>
          )}
          {drama.tags && drama.tags.length > 0 && (
            <span className="drama-tags">
              {drama.tags.slice(0, 2).join(' • ')}
            </span>
          )}
        </div>
      </div>
    </div>
  );
}

export default DramaCard;
