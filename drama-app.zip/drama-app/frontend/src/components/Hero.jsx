// src/components/Hero.jsx
import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Play, Info } from 'lucide-react';
import './Hero.css';

function Hero({ dramas }) {
  const [currentDrama, setCurrentDrama] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    if (dramas && dramas.length > 0) {
      // Pick a random drama for hero
      const randomIndex = Math.floor(Math.random() * Math.min(5, dramas.length));
      setCurrentDrama(dramas[randomIndex]);
    }
  }, [dramas]);

  if (!currentDrama) {
    return (
      <div className="hero-skeleton">
        <div className="spinner"></div>
      </div>
    );
  }

  const handlePlay = () => {
    navigate(`/detail/${currentDrama.provider}/${currentDrama.id}`);
  };

  const handleMoreInfo = () => {
    navigate(`/detail/${currentDrama.provider}/${currentDrama.id}`);
  };

  return (
    <div className="hero">
      <div className="hero-background">
        <img
          src={currentDrama.cover}
          alt={currentDrama.title}
          className="hero-image"
          onError={(e) => {
            e.target.style.display = 'none';
          }}
        />
        <div className="hero-gradient"></div>
      </div>

      <div className="hero-content">
        <h1 className="hero-title">{currentDrama.title}</h1>
        
        {currentDrama.description && (
          <p className="hero-description">
            {currentDrama.description.length > 200
              ? currentDrama.description.substring(0, 200) + '...'
              : currentDrama.description}
          </p>
        )}

        <div className="hero-info">
          {currentDrama.episodeCount && (
            <span className="hero-badge">{currentDrama.episodeCount} Episodes</span>
          )}
          {currentDrama.tags && currentDrama.tags.length > 0 && (
            <span className="hero-tags">
              {currentDrama.tags.slice(0, 3).join(' • ')}
            </span>
          )}
        </div>

        <div className="hero-buttons">
          <button className="hero-btn primary" onClick={handlePlay}>
            <Play size={24} fill="black" />
            <span>Play</span>
          </button>
          <button className="hero-btn secondary" onClick={handleMoreInfo}>
            <Info size={24} />
            <span>More Info</span>
          </button>
        </div>
      </div>
    </div>
  );
}

export default Hero;
