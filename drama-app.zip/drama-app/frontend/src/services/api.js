// src/services/api.js
import axios from 'axios';

const API_BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000/api';

const api = axios.create({
  baseURL: API_BASE_URL,
  timeout: 30000,
  headers: {
    'Content-Type': 'application/json'
  }
});

export const dramaAPI = {
  // Get providers
  getProviders: () => api.get('/providers'),

  // Home page
  getHome: (provider = 'melolo') => api.get(`/${provider}/home`),

  // For You feed
  getForYou: (provider = 'melolo', page = 1) => 
    api.get(`/${provider}/foryou`, { params: { page } }),

  // Trending
  getTrending: (provider = 'melolo') => api.get(`/${provider}/trending`),

  // Latest
  getLatest: (provider = 'melolo') => api.get(`/${provider}/latest`),

  // Search
  search: (provider = 'melolo', query, limit = 20, offset = 0) =>
    api.get(`/${provider}/search`, { params: { query, limit, offset } }),

  // Detail
  getDetail: (provider = 'melolo', id) => api.get(`/${provider}/detail/${id}`),

  // Episodes
  getEpisodes: (provider = 'melolo', id) => api.get(`/${provider}/episodes/${id}`),

  // Watch
  getWatchInfo: (provider = 'melolo', videoId) => api.get(`/${provider}/watch/${videoId}`)
};

export default api;
