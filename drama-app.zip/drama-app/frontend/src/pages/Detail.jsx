// src/pages/Detail.jsx
import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Play, ArrowLeft } from 'lucide-react';
import { dramaAPI } from '../services/api';
import './Detail.css';

function Detail() {
  const { provider, id } = useParams();
  const navigate = useNavigate();
  const [drama, setDrama] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    fetchDramaDetail();
  }, [provider, id]);

  const fetchDramaDetail = async () => {
    try {
      setLoading(true);
      const response = await dramaAPI.getDetail(provider, id);
      setDrama(response.data.data);
      setError(null);
    } catch (err) {
      console.error('Failed to fetch drama detail:', err);
      setError('Failed to load drama details.');
    } finally {
      setLoading(false);
    }
  };

  const handlePlayEpisode = (episode) => {
    if (!episode.isLocked) {
      navigate(`/watch/${provider}/${id}/${episode.id}`);
    }
  };

  if (loading) {
    return (
      <div className="loading-container">
        <div className="spinner"></div>
      </div>
    );
  }

  if (error || !drama) {
    return (
      <div className="error-container">
        <h2>Drama not found</h2>
        <button className="retry-button" onClick={() => navigate('/')}>
          Go Home
        </button>
      </div>
    );
  }

  return (
    <div className="detail-page">
      <button className="back-button" onClick={() => navigate(-1)}>
        <ArrowLeft size={20} />
        <span>Back</span>
      </button>

      <div className="detail-hero">
        <div className="detail-background">
          <img src={drama.cover} alt={drama.title} />
          <div className="detail-gradient"></div>
        </div>

        <div className="detail-content">
          <h1 className="detail-title">{drama.title}</h1>
          
          <div className="detail-meta">
            {drama.totalEpisodes && (
              <span className="meta-badge">{drama.totalEpisodes} Episodes</span>
            )}
            {drama.provider && (
              <span className="meta-provider">{drama.provider}</span>
            )}
          </div>

          {drama.tags && drama.tags.length > 0 && (
            <div className="detail-tags">
              {drama.tags.map((tag, index) => (
                <span key={index} className="tag">{tag}</span>
              ))}
            </div>
          )}

          {drama.description && (
            <p className="detail-description">{drama.description}</p>
          )}
        </div>
      </div>

      {drama.episodes && drama.episodes.length > 0 && (
        <div className="episodes-section">
          <h2 className="section-title">Episodes</h2>
          <div className="episodes-grid">
            {drama.episodes.map((episode, index) => (
              <div
                key={episode.id}
                className={`episode-card ${episode.isLocked ? 'locked' : ''}`}
                onClick={() => handlePlayEpisode(episode)}
              >
                <div className="episode-thumbnail">
                  {episode.thumbnail ? (
                    <img src={episode.thumbnail} alt={episode.title} />
                  ) : (
                    <div className="thumbnail-placeholder">
                      <Play size={32} />
                    </div>
                  )}
                  {!episode.isLocked && (
                    <div className="play-overlay">
                      <Play size={32} fill="white" />
                    </div>
                  )}
                  {episode.isLocked && (
                    <div className="locked-overlay">
                      <span>🔒 Locked</span>
                    </div>
                  )}
                </div>
                <div className="episode-info">
                  <h3 className="episode-title">
                    {episode.episodeNumber}. {episode.title}
                  </h3>
                  {episode.duration && (
                    <span className="episode-duration">
                      {Math.floor(episode.duration / 60)}m
                    </span>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

export default Detail;
