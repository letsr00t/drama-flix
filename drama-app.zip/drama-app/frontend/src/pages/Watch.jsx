// src/pages/Watch.jsx
import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';
import { dramaAPI } from '../services/api';
import './Watch.css';

function Watch() {
  const { provider, dramaId, videoId } = useParams();
  const navigate = useNavigate();
  const [streamData, setStreamData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    fetchStreamData();
  }, [provider, videoId]);

  const fetchStreamData = async () => {
    try {
      setLoading(true);
      const response = await dramaAPI.getWatchInfo(provider, videoId);
      setStreamData(response.data.data);
      setError(null);
    } catch (err) {
      console.error('Failed to fetch stream data:', err);
      setError('Failed to load video. The episode may be locked or unavailable.');
    } finally {
      setLoading(false);
    }
  };

  const handleBack = () => {
    navigate(`/detail/${provider}/${dramaId}`);
  };

  if (loading) {
    return (
      <div className="watch-loading">
        <div className="spinner"></div>
        <p>Loading video...</p>
      </div>
    );
  }

  if (error || !streamData || !streamData.streamURL) {
    return (
      <div className="watch-error">
        <h2>Unable to play video</h2>
        <p>{error || 'This episode may be locked or unavailable.'}</p>
        <button className="back-to-detail-btn" onClick={handleBack}>
          Back to Drama
        </button>
      </div>
    );
  }

  return (
    <div className="watch-page">
      <button className="watch-back-button" onClick={handleBack}>
        <ArrowLeft size={20} />
        <span>Back to Drama</span>
      </button>

      <div className="video-container">
        <video
          controls
          autoPlay
          className="video-player"
          src={streamData.streamURL}
          onError={(e) => {
            console.error('Video playback error:', e);
            setError('Failed to play video. Please try again later.');
          }}
        >
          Your browser does not support the video tag.
        </video>
      </div>

      <div className="watch-info">
        <div className="watch-meta">
          <span className="watch-provider">{provider}</span>
          {streamData.quality && (
            <span className="watch-quality">{streamData.quality}</span>
          )}
          {streamData.format && (
            <span className="watch-format">{streamData.format.toUpperCase()}</span>
          )}
        </div>
        <p className="watch-notice">
          ⚠️ This is a free episode. Premium episodes require subscription.
        </p>
      </div>
    </div>
  );
}

export default Watch;
