// src/pages/Home.jsx
import { useState, useEffect } from 'react';
import { dramaAPI } from '../services/api';
import Hero from '../components/Hero';
import DramaRow from '../components/DramaRow';
import './Home.css';

function Home() {
  const [loading, setLoading] = useState(true);
  const [homeData, setHomeData] = useState(null);
  const [error, setError] = useState(null);

  useEffect(() => {
    fetchHomeData();
  }, []);

  const fetchHomeData = async () => {
    try {
      setLoading(true);
      const response = await dramaAPI.getHome('melolo');
      setHomeData(response.data.data);
      setError(null);
    } catch (err) {
      console.error('Failed to fetch home data:', err);
      setError('Failed to load content. Please try again later.');
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="loading-container">
        <div className="spinner"></div>
        <p className="loading-text">Loading amazing dramas...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="error-container">
        <h2>Oops! Something went wrong</h2>
        <p>{error}</p>
        <button className="retry-button" onClick={fetchHomeData}>
          Try Again
        </button>
      </div>
    );
  }

  return (
    <div className="home">
      <Hero dramas={homeData?.forYou || homeData?.trending || []} />
      
      {homeData?.trending && homeData.trending.length > 0 && (
        <DramaRow title="🔥 Trending Now" dramas={homeData.trending} />
      )}
      
      {homeData?.forYou && homeData.forYou.length > 0 && (
        <DramaRow title="📺 For You" dramas={homeData.forYou} />
      )}
      
      {homeData?.latest && homeData.latest.length > 0 && (
        <DramaRow title="🆕 Latest Releases" dramas={homeData.latest} />
      )}
    </div>
  );
}

export default Home;
