// src/pages/Search.jsx
import { useState, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Search as SearchIcon } from 'lucide-react';
import { dramaAPI } from '../services/api';
import DramaCard from '../components/DramaCard';
import './Search.css';

function Search() {
  const [searchParams] = useSearchParams();
  const query = searchParams.get('q') || '';
  
  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    if (query) {
      performSearch(query);
    }
  }, [query]);

  const performSearch = async (searchQuery) => {
    try {
      setLoading(true);
      setError(null);
      const response = await dramaAPI.search('melolo', searchQuery, 20, 0);
      setResults(response.data.data.items || []);
    } catch (err) {
      console.error('Search failed:', err);
      setError('Failed to search. Please try again.');
      setResults([]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="search-page">
      <div className="search-header">
        <h1 className="search-title">
          {query ? `Search Results for "${query}"` : 'Search Dramas'}
        </h1>
        {!loading && results.length > 0 && (
          <p className="search-count">{results.length} results found</p>
        )}
      </div>

      {loading && (
        <div className="search-loading">
          <div className="spinner"></div>
          <p>Searching...</p>
        </div>
      )}

      {error && (
        <div className="search-error">
          <p>{error}</p>
        </div>
      )}

      {!loading && !error && results.length === 0 && query && (
        <div className="search-empty">
          <SearchIcon size={64} strokeWidth={1} />
          <h2>No results found</h2>
          <p>Try different keywords or browse our collection</p>
        </div>
      )}

      {!loading && results.length > 0 && (
        <div className="search-results">
          {results.map((drama, index) => (
            <DramaCard key={`${drama.id}-${index}`} drama={drama} />
          ))}
        </div>
      )}
    </div>
  );
}

export default Search;
