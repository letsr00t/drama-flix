# API Documentation - DramaFlix

## Base URL
```
http://localhost:5000/api
```

## Endpoints

### 1. Health Check
Check if the API is running.

**Endpoint:** `GET /health`

**Response:**
```json
{
  "success": true,
  "data": {
    "status": "OK",
    "uptime": 12345.67,
    "timestamp": "2026-04-14T10:30:00.000Z"
  },
  "meta": {
    "timestamp": "2026-04-14T10:30:00.000Z"
  }
}
```

---

### 2. Get Providers
Get list of available drama providers.

**Endpoint:** `GET /providers`

**Response:**
```json
{
  "success": true,
  "data": [
    {
      "name": "melolo",
      "capabilities": {
        "hasForYou": true,
        "hasTrending": true,
        "hasLatest": true,
        "hasSearch": true,
        "hasDetail": true,
        "hasStream": true,
        "requiresAuth": false
      },
      "info": {
        "name": "MeloLo",
        "baseURL": "https://api.tmtreader.com"
      }
    }
  ]
}
```

---

### 3. Get Home Content
Get aggregated home page content (For You + Trending + Latest).

**Endpoint:** `GET /:provider/home`

**Parameters:**
- `provider` (path) - Provider name (e.g., "melolo")

**Example:**
```
GET /melolo/home
```

**Response:**
```json
{
  "success": true,
  "data": {
    "provider": "melolo",
    "forYou": [
      {
        "id": "7583531888644459525",
        "title": "Drama Title",
        "cover": "https://image.url/cover.jpg",
        "description": "Drama description",
        "tags": ["Romance", "Drama"],
        "episodeCount": 100,
        "playCount": 1250000,
        "provider": "melolo"
      }
    ],
    "trending": [...],
    "latest": [...]
  }
}
```

---

### 4. Get For You Feed
Get personalized recommendations.

**Endpoint:** `GET /:provider/foryou`

**Parameters:**
- `provider` (path) - Provider name
- `page` (query, optional) - Page number (default: 1)

**Example:**
```
GET /melolo/foryou?page=1
```

**Response:**
```json
{
  "success": true,
  "data": {
    "provider": "melolo",
    "items": [
      {
        "id": "...",
        "title": "...",
        "cover": "...",
        "description": "...",
        "tags": [],
        "episodeCount": 0,
        "provider": "melolo"
      }
    ]
  }
}
```

---

### 5. Get Trending
Get trending dramas.

**Endpoint:** `GET /:provider/trending`

**Parameters:**
- `provider` (path) - Provider name

**Example:**
```
GET /melolo/trending
```

**Response:** Same as For You feed

---

### 6. Get Latest
Get latest released dramas.

**Endpoint:** `GET /:provider/latest`

**Parameters:**
- `provider` (path) - Provider name

**Example:**
```
GET /melolo/latest
```

**Response:** Same as For You feed

---

### 7. Search Dramas
Search for dramas by keyword.

**Endpoint:** `GET /:provider/search`

**Parameters:**
- `provider` (path) - Provider name
- `query` (query, required) - Search keyword
- `limit` (query, optional) - Results per page (default: 10)
- `offset` (query, optional) - Results offset (default: 0)

**Example:**
```
GET /melolo/search?query=love&limit=20&offset=0
```

**Response:**
```json
{
  "success": true,
  "data": {
    "provider": "melolo",
    "total": 156,
    "items": [...]
  }
}
```

---

### 8. Get Drama Detail
Get detailed information about a specific drama.

**Endpoint:** `GET /:provider/detail/:id`

**Parameters:**
- `provider` (path) - Provider name
- `id` (path) - Drama ID

**Example:**
```
GET /melolo/detail/7583531888644459525
```

**Response:**
```json
{
  "success": true,
  "data": {
    "provider": "melolo",
    "id": "7583531888644459525",
    "title": "Drama Title",
    "cover": "https://image.url/cover.jpg",
    "description": "Full description...",
    "tags": ["Romance", "Drama", "Family"],
    "totalEpisodes": 100,
    "episodes": [
      {
        "id": "7583564321033030661",
        "episodeNumber": 1,
        "title": "Episode 1",
        "duration": 180,
        "thumbnail": "https://image.url/ep1.jpg",
        "isLocked": false,
        "provider": "melolo"
      }
    ]
  }
}
```

---

### 9. Get Episodes
Get episode list for a drama.

**Endpoint:** `GET /:provider/episodes/:id`

**Parameters:**
- `provider` (path) - Provider name
- `id` (path) - Drama ID

**Example:**
```
GET /melolo/episodes/7583531888644459525
```

**Response:**
```json
{
  "success": true,
  "data": [
    {
      "id": "7583564321033030661",
      "episodeNumber": 1,
      "title": "Episode 1",
      "duration": 180,
      "thumbnail": "https://image.url/ep1.jpg",
      "isLocked": false,
      "provider": "melolo"
    }
  ]
}
```

---

### 10. Get Watch Info
Get streaming information for an episode.

**Endpoint:** `GET /:provider/watch/:videoId`

**Parameters:**
- `provider` (path) - Provider name
- `videoId` (path) - Episode/Video ID

**Example:**
```
GET /melolo/watch/7583564321033030661
```

**Response:**
```json
{
  "success": true,
  "data": {
    "provider": "melolo",
    "videoId": "7583564321033030661",
    "streamURL": "https://stream.url/video.m3u8",
    "quality": "HD",
    "duration": 180,
    "format": "m3u8"
  }
}
```

---

### 11. Get System Stats
Get cache and queue statistics.

**Endpoint:** `GET /stats`

**Response:**
```json
{
  "success": true,
  "data": {
    "cache": {
      "hits": 1523,
      "misses": 234,
      "sets": 234,
      "deletes": 12,
      "keys": 156,
      "hitRate": 0.867
    },
    "queue": {
      "queueLength": 3,
      "processing": 2,
      "paused": false
    }
  }
}
```

---

## Error Responses

### 400 Bad Request
```json
{
  "success": false,
  "error": {
    "code": 400,
    "message": "Query parameter is required",
    "timestamp": "2026-04-14T10:30:00.000Z"
  }
}
```

### 404 Not Found
```json
{
  "success": false,
  "error": {
    "code": 404,
    "message": "Provider \"invalid\" not found",
    "timestamp": "2026-04-14T10:30:00.000Z"
  }
}
```

### 429 Too Many Requests
```json
{
  "success": false,
  "error": {
    "code": 429,
    "message": "Too many requests, please try again later.",
    "timestamp": "2026-04-14T10:30:00.000Z"
  }
}
```

### 500 Internal Server Error
```json
{
  "success": false,
  "error": {
    "code": 500,
    "message": "Internal server error",
    "timestamp": "2026-04-14T10:30:00.000Z"
  }
}
```

---

## Rate Limiting

- **Window:** 60 seconds
- **Max Requests:** 100 requests per minute per IP
- **Headers:**
  - `X-RateLimit-Limit`: Maximum requests allowed
  - `X-RateLimit-Remaining`: Remaining requests
  - `X-RateLimit-Reset`: Time when limit resets

---

## Caching

Responses are cached to improve performance:

- **Home:** 30 minutes
- **For You:** 1 hour
- **Trending:** 30 minutes
- **Latest:** 30 minutes
- **Search:** 30 minutes
- **Detail:** 1 hour
- **Episodes:** 1 hour
- **Watch:** 10 minutes

---

## Best Practices

1. **Use appropriate endpoints**: Don't call `/detail` when `/home` suffices
2. **Implement caching**: Cache responses on client side
3. **Handle errors gracefully**: Always check `success` field
4. **Respect rate limits**: Implement exponential backoff
5. **Pagination**: Use pagination for large datasets

---

## Example Client Implementation

```javascript
// api-client.js
class DramaAPI {
  constructor(baseURL = 'http://localhost:5000/api') {
    this.baseURL = baseURL;
    this.provider = 'melolo';
  }

  async request(endpoint) {
    const response = await fetch(`${this.baseURL}${endpoint}`);
    const data = await response.json();
    
    if (!data.success) {
      throw new Error(data.error.message);
    }
    
    return data.data;
  }

  async getHome() {
    return this.request(`/${this.provider}/home`);
  }

  async search(query) {
    return this.request(`/${this.provider}/search?query=${encodeURIComponent(query)}`);
  }

  async getDetail(id) {
    return this.request(`/${this.provider}/detail/${id}`);
  }

  async getWatchInfo(videoId) {
    return this.request(`/${this.provider}/watch/${videoId}`);
  }
}

// Usage
const api = new DramaAPI();

async function loadHome() {
  try {
    const home = await api.getHome();
    console.log('Trending:', home.trending);
  } catch (error) {
    console.error('Failed to load:', error.message);
  }
}
```

---

For more information, see the main [README.md](README.md)
