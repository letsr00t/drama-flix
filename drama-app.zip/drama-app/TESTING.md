# 🧪 Testing Guide - DramaFlix

## Manual Testing Checklist

### Backend API Testing

#### 1. Health Check
```bash
curl http://localhost:5000/api/health
```
Expected: `{ "success": true, "data": { "status": "OK" } }`

#### 2. Get Providers
```bash
curl http://localhost:5000/api/providers
```
Expected: List of available providers

#### 3. Get Home Content
```bash
curl http://localhost:5000/api/melolo/home
```
Expected: Object with forYou, trending, latest arrays

#### 4. Search Dramas
```bash
curl "http://localhost:5000/api/melolo/search?query=love&limit=5"
```
Expected: Search results with dramas

#### 5. Get Drama Detail
```bash
# Replace ID with actual drama ID from search results
curl http://localhost:5000/api/melolo/detail/7583531888644459525
```
Expected: Drama details with episodes

#### 6. Get Episodes
```bash
curl http://localhost:5000/api/melolo/episodes/7583531888644459525
```
Expected: Array of episodes

#### 7. Get Stream URL (Free Episode Only)
```bash
# Replace videoId with actual free episode ID
curl http://localhost:5000/api/melolo/watch/7583564321033030661
```
Expected: Stream URL and metadata

### Frontend Testing

#### 1. Navigation Testing
- [ ] Home page loads
- [ ] Click on drama card
- [ ] Navigate to detail page
- [ ] Back button works
- [ ] Search functionality
- [ ] Direct URL navigation

#### 2. Component Testing

**Navbar:**
- [ ] Logo click returns to home
- [ ] Search icon opens search input
- [ ] Search submission works
- [ ] Mobile menu toggle works
- [ ] Navbar becomes opaque on scroll

**Hero Banner:**
- [ ] Hero image loads
- [ ] Play button navigates to detail
- [ ] More Info button navigates to detail
- [ ] Responsive on mobile

**Drama Row:**
- [ ] Horizontal scroll works
- [ ] Arrow buttons appear on hover
- [ ] Cards are clickable
- [ ] Responsive on mobile

**Drama Card:**
- [ ] Image loads with fallback
- [ ] Hover overlay appears
- [ ] Play button works
- [ ] Info button works

#### 3. Page Testing

**Home Page:**
- [ ] Hero banner displays
- [ ] Trending section loads
- [ ] For You section loads
- [ ] Latest section loads
- [ ] Loading state shows
- [ ] Error state shows (disconnect backend)

**Detail Page:**
- [ ] Drama details load
- [ ] Cover image displays
- [ ] Episode grid displays
- [ ] Locked episodes show lock icon
- [ ] Free episodes are clickable
- [ ] Back button works

**Search Page:**
- [ ] Search results display
- [ ] Empty state shows for no results
- [ ] Loading state works
- [ ] Grid layout responsive

**Watch Page:**
- [ ] Video player loads
- [ ] Video controls work
- [ ] Back button works
- [ ] Error handling for locked episodes
- [ ] Fullscreen works

#### 4. Responsive Testing

**Desktop (1920px):**
- [ ] Layout looks good
- [ ] All features accessible
- [ ] No horizontal scroll

**Laptop (1366px):**
- [ ] Cards resize properly
- [ ] Navbar fits
- [ ] Hero scales

**Tablet (768px):**
- [ ] Mobile menu works
- [ ] Touch scrolling works
- [ ] Cards stack properly

**Mobile (375px):**
- [ ] All content visible
- [ ] Touch targets adequate
- [ ] Font sizes readable
- [ ] Images load

### Performance Testing

#### Backend Performance
```bash
# Install Apache Bench
# macOS: brew install apache-bench
# Linux: apt-get install apache2-utils

# Test 100 requests, 10 concurrent
ab -n 100 -c 10 http://localhost:5000/api/melolo/home

# Expected:
# - Requests per second: > 50
# - Mean response time: < 500ms
# - Failed requests: 0
```

#### Cache Testing
```bash
# First request (cache miss)
time curl http://localhost:5000/api/melolo/home

# Second request (cache hit - should be faster)
time curl http://localhost:5000/api/melolo/home

# Check cache stats
curl http://localhost:5000/api/stats
```

#### Rate Limiting Testing
```bash
# Send 150 requests quickly (limit is 100/min)
for i in {1..150}; do
  curl -s http://localhost:5000/api/melolo/home > /dev/null &
done

# Expected: Some requests return 429 (Too Many Requests)
```

### Browser Testing

#### Chrome/Edge
- [ ] All features work
- [ ] Console has no errors
- [ ] Network requests successful

#### Firefox
- [ ] All features work
- [ ] Console has no errors
- [ ] Network requests successful

#### Safari
- [ ] All features work
- [ ] Console has no errors
- [ ] Video playback works

#### Mobile Browsers
- [ ] Responsive design works
- [ ] Touch gestures work
- [ ] Video playback works

### Error Handling Testing

#### Backend Errors
```bash
# Test invalid provider
curl http://localhost:5000/api/invalid/home
# Expected: 404 error

# Test invalid drama ID
curl http://localhost:5000/api/melolo/detail/invalid
# Expected: Error message

# Test missing query parameter
curl http://localhost:5000/api/melolo/search
# Expected: 400 error
```

#### Frontend Errors
- [ ] Disconnect backend, check error states
- [ ] Navigate to invalid URL
- [ ] Try to play locked episode
- [ ] Submit empty search

### Security Testing

#### CORS Testing
```bash
# Test from different origin (should be blocked)
curl -H "Origin: http://evil.com" \
     -H "Access-Control-Request-Method: GET" \
     http://localhost:5000/api/health
```

#### Rate Limiting
- [ ] Verify rate limit headers
- [ ] Test limit enforcement
- [ ] Check cooldown period

### Data Validation Testing

#### Search
- [ ] Empty query handled
- [ ] Special characters handled
- [ ] Very long query handled

#### Pagination
- [ ] Page 1 works
- [ ] Page > 1 works
- [ ] Invalid page number handled

## Automated Testing Setup

### Backend Unit Tests (Future)
```javascript
// Example test structure
describe('Drama Service', () => {
  it('should fetch home data', async () => {
    const result = await DramaService.getHome('melolo');
    expect(result).toBeDefined();
    expect(result.forYou).toBeInstanceOf(Array);
  });
});
```

### Frontend Component Tests (Future)
```javascript
// Example test structure
describe('DramaCard', () => {
  it('should render drama information', () => {
    const drama = { title: 'Test', cover: 'url' };
    render(<DramaCard drama={drama} />);
    expect(screen.getByText('Test')).toBeInTheDocument();
  });
});
```

## Test Results Template

```
Date: ___________
Tester: _________

Backend Tests:
- Health Check: ☐ Pass ☐ Fail
- Providers: ☐ Pass ☐ Fail
- Home API: ☐ Pass ☐ Fail
- Search API: ☐ Pass ☐ Fail
- Detail API: ☐ Pass ☐ Fail
- Stream API: ☐ Pass ☐ Fail

Frontend Tests:
- Home Page: ☐ Pass ☐ Fail
- Detail Page: ☐ Pass ☐ Fail
- Search Page: ☐ Pass ☐ Fail
- Watch Page: ☐ Pass ☐ Fail

Performance:
- Backend Response Time: _____ms
- Frontend Load Time: _____ms
- Cache Hit Rate: _____%

Issues Found:
1. _________________
2. _________________
3. _________________
```

## Common Issues & Solutions

### Issue: CORS Error
**Solution:** Check ALLOWED_ORIGINS in backend/.env

### Issue: Videos not playing
**Solution:** Verify episode is not locked, check stream URL

### Issue: Slow performance
**Solution:** Check cache configuration, verify rate limiting

### Issue: 404 on refresh
**Solution:** Configure web server for SPA routing

---

**Happy Testing! 🧪**
