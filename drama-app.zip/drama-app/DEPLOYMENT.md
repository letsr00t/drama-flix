# 🚀 Deployment Guide - DramaFlix

## Table of Contents
1. [Local Deployment](#local-deployment)
2. [Docker Deployment](#docker-deployment)
3. [Cloud Deployment](#cloud-deployment)
4. [Production Checklist](#production-checklist)

---

## Local Deployment

### Prerequisites
- Node.js 16.x or higher
- npm or yarn
- Git

### Step 1: Clone Repository
```bash
git clone <repository-url>
cd drama-app
```

### Step 2: Backend Setup
```bash
cd backend
npm install
cp .env.example .env
# Edit .env with your configuration
npm start
```

### Step 3: Frontend Setup
```bash
cd ../frontend
npm install
npm run dev
```

### Step 4: Access Application
- Frontend: http://localhost:3000
- Backend API: http://localhost:5000

---

## Docker Deployment

### Prerequisites
- Docker Desktop installed
- docker-compose installed

### Quick Start with Docker
```bash
# Build and start all services
docker-compose up -d

# View logs
docker-compose logs -f

# Stop all services
docker-compose down
```

### Manual Docker Build

**Backend:**
```bash
cd backend
docker build -t dramaflix-backend .
docker run -p 5000:5000 -e NODE_ENV=production dramaflix-backend
```

**Frontend:**
```bash
cd frontend
docker build -t dramaflix-frontend .
docker run -p 3000:80 dramaflix-frontend
```

---

## Cloud Deployment

### Option 1: Vercel (Frontend) + Render (Backend)

#### Deploy Backend to Render
1. Create account on [Render.com](https://render.com)
2. New Web Service
3. Connect GitHub repository
4. Configure:
   - **Build Command:** `cd backend && npm install`
   - **Start Command:** `cd backend && npm start`
   - **Environment Variables:**
     ```
     NODE_ENV=production
     PORT=5000
     ALLOWED_ORIGINS=https://your-frontend.vercel.app
     ```
5. Deploy

#### Deploy Frontend to Vercel
1. Install Vercel CLI: `npm i -g vercel`
2. Navigate to frontend: `cd frontend`
3. Deploy: `vercel`
4. Update API URL:
   ```javascript
   // src/services/api.js
   const API_BASE_URL = process.env.VITE_API_URL || 
                        'https://your-backend.onrender.com/api';
   ```
5. Redeploy: `vercel --prod`

#### Environment Variables (Vercel)
```
VITE_API_URL=https://your-backend.onrender.com/api
```

---

### Option 2: Railway (Full Stack)

1. Create account on [Railway.app](https://railway.app)
2. New Project
3. Deploy Backend:
   - Add service from GitHub
   - Root directory: `backend`
   - Build command: `npm install`
   - Start command: `npm start`
   - Environment variables: See backend/.env.example
4. Deploy Frontend:
   - Add service from GitHub
   - Root directory: `frontend`
   - Build command: `npm install && npm run build`
   - Start command: `npx serve dist -p $PORT`
5. Connect services

---

### Option 3: AWS (EC2)

#### Backend on EC2
```bash
# SSH into EC2 instance
ssh -i key.pem ubuntu@your-ec2-ip

# Install Node.js
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt-get install -y nodejs

# Clone repository
git clone <repository-url>
cd drama-app/backend

# Install dependencies
npm install --production

# Install PM2
sudo npm install -g pm2

# Start application
pm2 start src/app.js --name dramaflix-backend

# Save PM2 configuration
pm2 save
pm2 startup
```

#### Frontend on S3 + CloudFront
```bash
# Build frontend
cd frontend
npm run build

# Install AWS CLI
pip install awscli

# Upload to S3
aws s3 sync dist/ s3://your-bucket-name

# Configure CloudFront distribution
# Point to S3 bucket
# Set custom domain if needed
```

---

### Option 4: Heroku

#### Backend Deployment
```bash
cd backend

# Login to Heroku
heroku login

# Create app
heroku create dramaflix-backend

# Set environment variables
heroku config:set NODE_ENV=production
heroku config:set ALLOWED_ORIGINS=https://your-frontend.herokuapp.com

# Deploy
git init
git add .
git commit -m "Deploy backend"
git push heroku main
```

#### Frontend Deployment
```bash
cd frontend

# Create app
heroku create dramaflix-frontend

# Add buildpack
heroku buildpacks:set https://github.com/mars/create-react-app-buildpack.git

# Set environment
heroku config:set VITE_API_URL=https://dramaflix-backend.herokuapp.com/api

# Deploy
git init
git add .
git commit -m "Deploy frontend"
git push heroku main
```

---

### Option 5: DigitalOcean (Droplet)

#### Setup Droplet
```bash
# Create Ubuntu droplet
# SSH into droplet
ssh root@your-droplet-ip

# Update system
apt update && apt upgrade -y

# Install Node.js
curl -fsSL https://deb.nodesource.com/setup_18.x | bash -
apt install -y nodejs

# Install nginx
apt install -y nginx

# Install PM2
npm install -g pm2
```

#### Deploy Application
```bash
# Clone repository
cd /var/www
git clone <repository-url> dramaflix
cd dramaflix

# Backend setup
cd backend
npm install --production
pm2 start src/app.js --name backend
pm2 save
pm2 startup

# Frontend build
cd ../frontend
npm install
npm run build

# Configure nginx
nano /etc/nginx/sites-available/dramaflix
```

**Nginx Configuration:**
```nginx
server {
    listen 80;
    server_name your-domain.com;

    # Frontend
    location / {
        root /var/www/dramaflix/frontend/dist;
        try_files $uri $uri/ /index.html;
    }

    # Backend API
    location /api {
        proxy_pass http://localhost:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }
}
```

```bash
# Enable site
ln -s /etc/nginx/sites-available/dramaflix /etc/nginx/sites-enabled/
nginx -t
systemctl restart nginx

# Setup SSL with Let's Encrypt
apt install certbot python3-certbot-nginx
certbot --nginx -d your-domain.com
```

---

## Production Checklist

### Backend
- [ ] Set `NODE_ENV=production`
- [ ] Configure proper CORS origins
- [ ] Set up rate limiting
- [ ] Enable compression
- [ ] Configure logging
- [ ] Set up error monitoring (e.g., Sentry)
- [ ] Use process manager (PM2, forever)
- [ ] Set up database (if needed)
- [ ] Configure backup strategy
- [ ] Set up health check endpoint
- [ ] Enable HTTPS
- [ ] Configure firewall rules

### Frontend
- [ ] Build optimized production bundle
- [ ] Set correct API URL
- [ ] Enable asset compression
- [ ] Configure CDN (optional)
- [ ] Set up analytics (Google Analytics)
- [ ] Configure error tracking
- [ ] Enable service worker (PWA - optional)
- [ ] Optimize images
- [ ] Set up proper caching headers
- [ ] Test on multiple browsers
- [ ] Test on multiple devices
- [ ] Enable HTTPS

### Security
- [ ] Use HTTPS everywhere
- [ ] Set security headers
- [ ] Implement CSRF protection
- [ ] Sanitize user inputs
- [ ] Use environment variables for secrets
- [ ] Set up WAF (Web Application Firewall)
- [ ] Regular security updates
- [ ] Implement authentication (if needed)
- [ ] Rate limiting configured
- [ ] DDoS protection (Cloudflare)

### Performance
- [ ] Enable gzip/brotli compression
- [ ] Implement caching strategy
- [ ] Use CDN for static assets
- [ ] Optimize database queries
- [ ] Enable HTTP/2
- [ ] Minify CSS/JS
- [ ] Lazy load images
- [ ] Code splitting
- [ ] Monitor performance metrics

### Monitoring
- [ ] Set up uptime monitoring
- [ ] Configure error tracking
- [ ] Set up performance monitoring
- [ ] Log aggregation
- [ ] Set up alerts
- [ ] Monitor server resources
- [ ] Track API usage
- [ ] Monitor cache hit rates

---

## Environment Variables (Production)

### Backend (.env)
```env
NODE_ENV=production
PORT=5000
ALLOWED_ORIGINS=https://your-domain.com
CACHE_TTL=7200
RATE_LIMIT_MAX_REQUESTS=50
```

### Frontend
```env
VITE_API_URL=https://api.your-domain.com
VITE_ENV=production
```

---

## Rollback Strategy

### Quick Rollback
```bash
# Backend
pm2 restart backend
git reset --hard HEAD~1
npm install
pm2 reload backend

# Frontend
git reset --hard HEAD~1
npm run build
# Redeploy to hosting
```

### Using PM2 Ecosystem
```javascript
// ecosystem.config.js
module.exports = {
  apps: [{
    name: 'dramaflix-backend',
    script: './src/app.js',
    instances: 2,
    exec_mode: 'cluster',
    env_production: {
      NODE_ENV: 'production',
      PORT: 5000
    }
  }]
};

// Deploy
pm2 start ecosystem.config.js --env production
pm2 save
```

---

## Troubleshooting Production

### Backend not responding
```bash
# Check if running
pm2 status

# View logs
pm2 logs backend

# Restart
pm2 restart backend
```

### Frontend not loading
```bash
# Check nginx
systemctl status nginx
nginx -t

# Check logs
tail -f /var/log/nginx/error.log
```

### High memory usage
```bash
# Check processes
htop

# Restart with memory limit
pm2 start app.js --max-memory-restart 500M
```

---

## Scaling

### Horizontal Scaling
- Use load balancer (nginx, HAProxy)
- Deploy multiple backend instances
- Use PM2 cluster mode
- Implement session management

### Vertical Scaling
- Upgrade server resources
- Optimize code
- Improve caching
- Database optimization

---

## Backup Strategy

### Automated Backups
```bash
#!/bin/bash
# backup.sh

# Backup directory
BACKUP_DIR="/backups/dramaflix"
DATE=$(date +%Y%m%d_%H%M%S)

# Create backup
tar -czf $BACKUP_DIR/backup_$DATE.tar.gz /var/www/dramaflix

# Keep only last 7 days
find $BACKUP_DIR -mtime +7 -delete

# Schedule with cron
# 0 2 * * * /path/to/backup.sh
```

---

**For detailed support, consult the main README.md or create an issue on GitHub.**
