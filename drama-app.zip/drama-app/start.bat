@echo off
REM DramaFlix - Windows Start Script

echo.
echo ========================================
echo    Starting DramaFlix Application
echo ========================================
echo.

REM Check if Node.js is installed
where node >nul 2>nul
if %errorlevel% neq 0 (
    echo [ERROR] Node.js is not installed!
    echo Please install Node.js from https://nodejs.org/
    pause
    exit /b 1
)

echo [OK] Node.js found
node --version
echo.

REM Backend Setup
echo [STEP 1] Setting up Backend...
cd backend

if not exist "node_modules\" (
    echo Installing backend dependencies...
    call npm install
) else (
    echo Backend dependencies already installed
)

echo Starting backend server on port 5000...
start "DramaFlix Backend" cmd /k npm start

timeout /t 3 /nobreak >nul

REM Frontend Setup
echo.
echo [STEP 2] Setting up Frontend...
cd ..\frontend

if not exist "node_modules\" (
    echo Installing frontend dependencies...
    call npm install
) else (
    echo Frontend dependencies already installed
)

echo.
echo ========================================
echo    DramaFlix is starting...
echo ========================================
echo    Backend:  http://localhost:5000
echo    Frontend: http://localhost:3000
echo ========================================
echo.
echo Starting frontend server on port 3000...
echo Close this window to stop all servers
echo.

call npm run dev

pause
