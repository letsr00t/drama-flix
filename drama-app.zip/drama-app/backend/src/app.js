// src/app.js
import express from 'express';
import dotenv from 'dotenv';
import { corsMiddleware } from './middlewares/cors.middleware.js';
import { rateLimiter } from './middlewares/rateLimit.middleware.js';
import { errorHandler } from './middlewares/error.middleware.js';
import apiRoutes from './routes/api.routes.js';

// Load environment variables
dotenv.config();

const app = express();
const PORT = process.env.PORT || 5000;

// Middlewares
app.use(corsMiddleware);
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(rateLimiter);

// Routes
app.use('/api', apiRoutes);

// Root endpoint
app.get('/', (req, res) => {
  res.json({
    message: 'Drama Streaming API',
    version: '1.0.0',
    endpoints: {
      health: '/api/health',
      providers: '/api/providers',
      stats: '/api/stats',
      home: '/api/:provider/home',
      forYou: '/api/:provider/foryou',
      trending: '/api/:provider/trending',
      latest: '/api/:provider/latest',
      search: '/api/:provider/search?query=',
      detail: '/api/:provider/detail/:id',
      episodes: '/api/:provider/episodes/:id',
      watch: '/api/:provider/watch/:videoId'
    },
    documentation: 'https://github.com/yourusername/drama-streaming-api'
  });
});

// 404 handler
app.use((req, res) => {
  res.status(404).json({
    success: false,
    error: {
      code: 404,
      message: 'Endpoint not found',
      path: req.path
    }
  });
});

// Error handler (must be last)
app.use(errorHandler);

// Start server
app.listen(PORT, () => {
  console.log('╔══════════════════════════════════════════╗');
  console.log('║   🎬  Drama Streaming API Server  🎬    ║');
  console.log('╠══════════════════════════════════════════╣');
  console.log(`║  Status: Running                         ║`);
  console.log(`║  Port: ${PORT}                              ║`);
  console.log(`║  Environment: ${process.env.NODE_ENV || 'development'}               ║`);
  console.log('╠══════════════════════════════════════════╣');
  console.log(`║  API: http://localhost:${PORT}/api           ║`);
  console.log(`║  Docs: http://localhost:${PORT}/              ║`);
  console.log('╚══════════════════════════════════════════╝');
});

export default app;
