// src/middlewares/error.middleware.js
import { errorResponse } from '../utils/response.helper.js';

export function errorHandler(err, req, res, next) {
  console.error('Error:', err);

  // Axios errors
  if (err.response) {
    return res.status(err.response.status || 500).json(
      errorResponse(
        'External API error',
        err.response.status,
        err.response.data
      )
    );
  }

  // Validation errors
  if (err.name === 'ValidationError') {
    return res.status(400).json(
      errorResponse('Validation error', 400, err.details)
    );
  }

  // Provider not found
  if (err.message && err.message.includes('not found')) {
    return res.status(404).json(
      errorResponse(err.message, 404)
    );
  }

  // Default error
  res.status(500).json(
    errorResponse(
      err.message || 'Internal server error',
      500
    )
  );
}
