// src/services/drama.service.js
import { providerRegistry } from '../providers/index.js';
import CacheHelper from '../utils/cache.helper.js';
import QueueHelper from '../utils/queue.helper.js';

const cache = new CacheHelper(3600);
const queue = new QueueHelper(5, 1000);

export class DramaService {
  static async getForYou(providerName, page = 1) {
    const cacheKey = `${providerName}:forYou:${page}`;
    const cached = cache.get(cacheKey);
    
    if (cached) {
      return cached;
    }

    const provider = providerRegistry.get(providerName);
    const result = await queue.add(() => provider.getForYou(page));
    
    cache.set(cacheKey, result);
    return result;
  }

  static async getTrending(providerName) {
    const cacheKey = `${providerName}:trending`;
    const cached = cache.get(cacheKey);
    
    if (cached) {
      return cached;
    }

    const provider = providerRegistry.get(providerName);
    const result = await queue.add(() => provider.getTrending());
    
    cache.set(cacheKey, result, 1800);
    return result;
  }

  static async getLatest(providerName) {
    const cacheKey = `${providerName}:latest`;
    const cached = cache.get(cacheKey);
    
    if (cached) {
      return cached;
    }

    const provider = providerRegistry.get(providerName);
    const result = await queue.add(() => provider.getLatest());
    
    cache.set(cacheKey, result, 1800);
    return result;
  }

  static async search(providerName, query, options = {}) {
    const cacheKey = `${providerName}:search:${query}:${JSON.stringify(options)}`;
    const cached = cache.get(cacheKey);
    
    if (cached) {
      return cached;
    }

    const provider = providerRegistry.get(providerName);
    const result = await queue.add(() => provider.search(query, options));
    
    cache.set(cacheKey, result, 1800);
    return result;
  }

  static async getDetail(providerName, id) {
    const cacheKey = `${providerName}:detail:${id}`;
    const cached = cache.get(cacheKey);
    
    if (cached) {
      return cached;
    }

    const provider = providerRegistry.get(providerName);
    const result = await queue.add(() => provider.getDetail(id));
    
    cache.set(cacheKey, result);
    return result;
  }

  static async getEpisodes(providerName, id) {
    const cacheKey = `${providerName}:episodes:${id}`;
    const cached = cache.get(cacheKey);
    
    if (cached) {
      return cached;
    }

    const provider = providerRegistry.get(providerName);
    const result = await queue.add(() => provider.getEpisodes(id));
    
    cache.set(cacheKey, result);
    return result;
  }

  static async getWatchInfo(providerName, videoId) {
    const cacheKey = `${providerName}:watch:${videoId}`;
    const cached = cache.get(cacheKey);
    
    if (cached) {
      return cached;
    }

    const provider = providerRegistry.get(providerName);
    const result = await queue.add(() => provider.getWatchInfo(videoId));
    
    cache.set(cacheKey, result, 600);
    return result;
  }

  static async getHome(providerName) {
    const cacheKey = `${providerName}:home`;
    const cached = cache.get(cacheKey);
    
    if (cached) {
      return cached;
    }

    const provider = providerRegistry.get(providerName);
    
    // Aggregate multiple endpoints for home page
    const [forYou, trending, latest] = await Promise.all([
      queue.add(() => provider.getForYou(1)),
      queue.add(() => provider.getTrending()).catch(() => ({ items: [] })),
      queue.add(() => provider.getLatest()).catch(() => ({ items: [] }))
    ]);

    const result = {
      provider: providerName,
      forYou: forYou.items || [],
      trending: trending.items || [],
      latest: latest.items || []
    };

    cache.set(cacheKey, result, 1800);
    return result;
  }

  static getProviders() {
    return providerRegistry.getAll();
  }

  static getCacheStats() {
    return cache.getStats();
  }

  static getQueueStats() {
    return queue.getStats();
  }
}
