// src/routes/api.routes.js
import { Router } from 'express';
import { DramaService } from '../services/drama.service.js';
import { successResponse, errorResponse } from '../utils/response.helper.js';

const router = Router();

// Health check
router.get('/health', (req, res) => {
  res.json(successResponse({
    status: 'OK',
    uptime: process.uptime(),
    timestamp: new Date().toISOString()
  }));
});

// Get available providers
router.get('/providers', (req, res) => {
  const providers = DramaService.getProviders();
  res.json(successResponse(providers));
});

// Get system stats
router.get('/stats', (req, res) => {
  const stats = {
    cache: DramaService.getCacheStats(),
    queue: DramaService.getQueueStats()
  };
  res.json(successResponse(stats));
});

// Get home page (aggregated content)
router.get('/:provider/home', async (req, res, next) => {
  try {
    const { provider } = req.params;
    const result = await DramaService.getHome(provider);
    res.json(successResponse(result));
  } catch (error) {
    next(error);
  }
});

// Get for you feed
router.get('/:provider/foryou', async (req, res, next) => {
  try {
    const { provider } = req.params;
    const { page = 1 } = req.query;
    
    const result = await DramaService.getForYou(provider, parseInt(page));
    res.json(successResponse(result));
  } catch (error) {
    next(error);
  }
});

// Get trending
router.get('/:provider/trending', async (req, res, next) => {
  try {
    const { provider } = req.params;
    const result = await DramaService.getTrending(provider);
    res.json(successResponse(result));
  } catch (error) {
    next(error);
  }
});

// Get latest
router.get('/:provider/latest', async (req, res, next) => {
  try {
    const { provider } = req.params;
    const result = await DramaService.getLatest(provider);
    res.json(successResponse(result));
  } catch (error) {
    next(error);
  }
});

// Search
router.get('/:provider/search', async (req, res, next) => {
  try {
    const { provider } = req.params;
    const { query, limit = 10, offset = 0 } = req.query;
    
    if (!query) {
      return res.status(400).json(
        errorResponse('Query parameter is required', 400)
      );
    }
    
    const result = await DramaService.search(provider, query, {
      limit: parseInt(limit),
      offset: parseInt(offset)
    });
    
    res.json(successResponse(result));
  } catch (error) {
    next(error);
  }
});

// Get detail
router.get('/:provider/detail/:id', async (req, res, next) => {
  try {
    const { provider, id } = req.params;
    const result = await DramaService.getDetail(provider, id);
    res.json(successResponse(result));
  } catch (error) {
    next(error);
  }
});

// Get episodes
router.get('/:provider/episodes/:id', async (req, res, next) => {
  try {
    const { provider, id } = req.params;
    const result = await DramaService.getEpisodes(provider, id);
    res.json(successResponse(result));
  } catch (error) {
    next(error);
  }
});

// Get watch info
router.get('/:provider/watch/:videoId', async (req, res, next) => {
  try {
    const { provider, videoId } = req.params;
    const result = await DramaService.getWatchInfo(provider, videoId);
    res.json(successResponse(result));
  } catch (error) {
    next(error);
  }
});

export default router;
