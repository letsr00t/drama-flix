// src/providers/melolo.provider.js
import axios from 'axios';
import { BaseProvider } from './base.provider.js';

export class MeloLoProvider extends BaseProvider {
  constructor() {
    super({
      name: 'MeloLo',
      baseURL: 'https://api.tmtreader.com',
      capabilities: {
        hasForYou: true,
        hasTrending: true,
        hasLatest: true,
        hasSearch: true,
        hasDetail: true,
        hasStream: true,
        requiresAuth: false
      }
    });

    // Common headers
    this.commonHeaders = {
      'User-Agent': 'com.worldance.drama/49819 (Linux; U; Android 13; in; SM-A042F; Build/TP1A.220624.014; Cronet/TTNetVersion:8f366453 2024-12-24 QuicVersion:ef6c341e 2024-11-14)',
      'Accept': 'application/json; charset=utf-8,application/x-protobuf',
      'Accept-Encoding': 'gzip, deflate',
      'x-xs-from-web': 'false',
      'age-range': '8'
    };

    // Common params
    this.commonParams = {
      iid: '7604173033750415125',
      device_id: '7554232785717380664',
      ac: 'mobile',
      channel: 'gp',
      aid: '645713',
      app_name: 'Melolo',
      version_code: '51617',
      version_name: '5.1.6',
      device_platform: 'android',
      os: 'android',
      ssmix: 'a',
      device_type: 'SM-A042F',
      device_brand: 'samsung',
      language: 'in',
      os_api: '33',
      os_version: '13',
      openudid: 'd7ad3f25422073a0',
      manifest_version_code: '51617',
      resolution: '720*1465',
      dpi: '300',
      update_version_code: '51617',
      current_region: 'ID',
      carrier_region: 'id',
      app_language: 'id',
      sys_language: 'in',
      app_region: 'ID',
      prefer_gd: '0',
      sys_region: 'ID',
      mcc_mnc: '51001',
      carrier_region_v2: '510',
      user_language: 'id',
      ui_language: 'in',
      cdid: '245817c0-0db2-4417-9483-e535ug421t12',
      time_zone: 'Asia/Makassar'
    };
  }

  buildQueryString(params) {
    return Object.keys(params)
      .map(key => `${encodeURIComponent(key)}=${encodeURIComponent(params[key])}`)
      .join('&');
  }

  async getForYou(page = 0) {
    try {
      const offset = page * 10;
      const params = {
        ...this.commonParams,
        max_abstract_len: 0,
        selected_tag_id: -1,
        selected_tag_type: 2,
        offset: offset,
        is_preload: false,
        recommend_enable_write_client_session_cache_only: false,
        preference_strategy: 0,
        session_id: '202602080139170E88047C6763DB9510C5',
        change_type: 0,
        enable_new_show_mechanism: false,
        is_preference_force_insert: false,
        is_landing_page: 0,
        tab_scene: 3,
        tab_type: 0,
        limit: 10,
        start_offset: 0,
        cell_id: '7450059162446200848',
        _rticket: Date.now()
      };

      const url = `${this.baseURL}/i18n_novel/bookmall/cell/change/v1/?${this.buildQueryString(params)}`;
      const response = await axios.get(url, { headers: this.commonHeaders });

      const items = response.data?.data?.goods_list || [];
      return items.map(item => this.normalizeDrama(item));
    } catch (error) {
      console.error('MeloLo getForYou error:', error.message);
      return [];
    }
  }

  async getTrending() {
    try {
      const params = {
        ...this.commonParams,
        feature_switch: JSON.stringify({enable_drama_infinite_filter:false,enable_filter_page:true}),
        last_query: 'cinta',
        _rticket: Date.now()
      };

      const url = `${this.baseURL}/i18n_novel/search/front_page/v1/?${this.buildQueryString(params)}`;
      const response = await axios.get(url, { headers: this.commonHeaders });

      const trendingData = response.data?.data?.[0];
      const items = trendingData?.result || [];
      
      return items.map(item => this.normalizeDrama(item));
    } catch (error) {
      console.error('MeloLo getTrending error:', error.message);
      return [];
    }
  }

  async getLatest() {
    try {
      const params = {
        ...this.commonParams,
        feature_switch: JSON.stringify({enable_drama_infinite_filter:false,enable_filter_page:true}),
        last_query: 'cinta',
        _rticket: Date.now()
      };

      const url = `${this.baseURL}/i18n_novel/search/front_page/v1/?${this.buildQueryString(params)}`;
      const response = await axios.get(url, { headers: this.commonHeaders });

      const latestData = response.data?.data?.[2];
      const items = latestData?.result || [];
      
      return items.map(item => this.normalizeDrama(item));
    } catch (error) {
      console.error('MeloLo getLatest error:', error.message);
      return [];
    }
  }

  async search(query, options = {}) {
    try {
      const { limit = 10, offset = 0 } = options;
      
      const params = {
        ...this.commonParams,
        search_source_id: 'clks###',
        IsFetchDebug: false,
        offset: offset,
        cancel_search_category_enhance: false,
        query: query,
        limit: limit,
        _rticket: Date.now()
      };

      const url = `${this.baseURL}/i18n_novel/search/page/v1/?${this.buildQueryString(params)}`;
      const response = await axios.get(url, { headers: this.commonHeaders });

      const items = response.data?.data?.result || [];
      return items.map(item => this.normalizeDrama(item));
    } catch (error) {
      console.error('MeloLo search error:', error.message);
      return [];
    }
  }

  async getDetail(seriesId) {
    try {
      const params = {
        ...this.commonParams,
        _rticket: Date.now()
      };

      const url = `${this.baseURL}/novel/player/video_detail/v1/?${this.buildQueryString(params)}`;
      
      const data = {
        biz_param: {
          detail_page_version: 0,
          from_video_id: '',
          need_all_video_definition: false,
          need_mp4_align: false,
          source: 4,
          use_os_player: false,
          video_id_type: 1
        },
        series_id: seriesId
      };

      const response = await axios.post(url, data, { headers: this.commonHeaders });
      
      return this.normalizeDetail(response.data);
    } catch (error) {
      console.error('MeloLo getDetail error:', error.message);
      throw error;
    }
  }

  async getWatchInfo(videoId) {
    try {
      const params = {
        ...this.commonParams,
        version_code: '49819',
        version_name: '4.9.8',
        manifest_version_code: '49819',
        update_version_code: '49819',
        _rticket: Date.now()
      };

      const url = `${this.baseURL}/novel/player/video_model/v1/?${this.buildQueryString(params)}`;
      
      const data = {
        biz_param: {
          detail_page_version: 0,
          device_level: 3,
          from_video_id: '',
          need_all_video_definition: true,
          need_mp4_align: false,
          source: 4,
          use_os_player: false,
          use_server_dns: false,
          video_id_type: 0,
          video_platform: 3
        },
        video_id: videoId
      };

      const response = await axios.post(url, data, { headers: this.commonHeaders });
      
      return this.normalizeStream(response.data);
    } catch (error) {
      console.error('MeloLo getWatchInfo error:', error.message);
      throw error;
    }
  }

  normalizeDrama(item) {
    return {
      id: item.search_source_book_id || item.book_id || item.id,
      title: item.book_name || item.title,
      cover: item.banner_url || item.img_url || item.cover,
      description: item.book_abstract || item.description || '',
      tags: item.tags || [],
      episodeCount: item.total_episodes || item.episode_count || 0,
      playCount: item.play_count || 0,
      provider: 'melolo'
    };
  }

  normalizeDetail(data) {
    const detail = data?.data || {};
    const episodes = detail.videos || [];

    return {
      id: detail.series_id,
      title: detail.series_name || detail.title,
      cover: detail.cover_url || detail.cover,
      description: detail.description || '',
      tags: detail.tags || [],
      totalEpisodes: episodes.length,
      episodes: episodes.map((ep, index) => ({
        id: ep.vid,
        episodeNumber: index + 1,
        title: ep.title || `Episode ${index + 1}`,
        duration: ep.duration || 0,
        thumbnail: ep.cover_url,
        isLocked: ep.is_locked || false,
        provider: 'melolo'
      })),
      provider: 'melolo'
    };
  }

  normalizeStream(data) {
    const video = data?.data?.video_model || {};
    const playAddr = video.play_addr || {};
    const urls = playAddr.url_list || [];

    return {
      videoId: video.vid,
      streamURL: urls[0] || '',
      quality: video.definition || 'HD',
      duration: video.duration || 0,
      format: video.format || 'm3u8',
      provider: 'melolo'
    };
  }
}
