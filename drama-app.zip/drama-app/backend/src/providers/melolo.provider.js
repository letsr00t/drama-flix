// src/providers/melolo.provider.js
import { BaseProvider } from './base.provider.js';
import axios from 'axios';

export class MeloLoProvider extends BaseProvider {
  constructor() {
    super({
      name: 'MeloLo',
      baseURL: 'https://api.tmtreader.com',
      
      deviceProfile: {
        iid: '7604173033750415125',
        device_id: '7554232785717380664',
        openudid: 'd7ad3f25422073a0',
        cdid: '245817c0-0db2-4417-9483-e535ug421t12',
        device_type: 'SM-A042F',
        device_brand: 'samsung',
        resolution: '720*1465',
        dpi: '300'
      },
      
      appProfile: {
        aid: '645713',
        app_name: 'Melolo',
        channel: 'gp',
        version_code: '51617',
        version_name: '5.1.6',
        manifest_version_code: '51617',
        update_version_code: '51617',
        os: 'android',
        device_platform: 'android',
        os_api: '33',
        os_version: '13',
        ssmix: 'a',
        prefer_gd: '0',
        ac: 'mobile'
      },
      
      localeProfile: {
        time_zone: 'Asia/Jakarta',
        current_region: 'ID',
        carrier_region: 'id',
        carrier_region_v2: '510',
        app_region: 'ID',
        sys_region: 'ID',
        language: 'in',
        app_language: 'id',
        sys_language: 'in',
        user_language: 'id',
        ui_language: 'in',
        mcc_mnc: '51001'
      },
      
      headers: {
        'User-Agent': 'com.worldance.drama/51617 (Linux; U; Android 13; in; SM-A042F; Build/TP1A.220624.014)',
        'Accept': 'application/json; charset=utf-8',
        'Accept-Encoding': 'gzip, deflate',
        'x-xs-from-web': 'false',
        'age-range': '8'
      },
      
      capabilities: {
        hasForYou: true,
        hasTrending: true,
        hasLatest: true,
        hasSearch: true,
        hasDetail: true,
        hasStream: true,
        requiresAuth: false
      }
    });
  }

  buildCommonParams() {
    return {
      ...this.config.deviceProfile,
      ...this.config.appProfile,
      ...this.config.localeProfile,
      _rticket: Date.now()
    };
  }

  async getForYou(page = 1) {
    const offset = (page - 1) * 20;
    const params = {
      ...this.buildCommonParams(),
      offset,
      limit: 20,
      max_abstract_len: 0,
      selected_tag_id: -1,
      selected_tag_type: 2,
      is_preload: false,
      cell_id: '7450059162446200848',
      tab_scene: 3,
      tab_type: 0
    };

    const response = await axios.get(
      this.buildURL('/i18n_novel/bookmall/cell/change/v1/', params),
      { headers: this.config.headers }
    );

    return this.normalizeForYou(response.data);
  }

  async getTrending() {
    const params = {
      ...this.buildCommonParams(),
      feature_switch: JSON.stringify({
        enable_drama_infinite_filter: false,
        enable_filter_page: true
      })
    };

    const response = await axios.get(
      this.buildURL('/i18n_novel/search/front_page/v1/', params),
      { headers: this.config.headers }
    );

    return this.normalizeFeed(response.data.data?.[0]);
  }

  async getLatest() {
    const params = {
      ...this.buildCommonParams(),
      feature_switch: JSON.stringify({
        enable_drama_infinite_filter: false,
        enable_filter_page: true
      })
    };

    const response = await axios.get(
      this.buildURL('/i18n_novel/search/front_page/v1/', params),
      { headers: this.config.headers }
    );

    return this.normalizeFeed(response.data.data?.[2]);
  }

  async search(query, options = {}) {
    const { limit = 10, offset = 0 } = options;
    
    const params = {
      ...this.buildCommonParams(),
      query,
      limit,
      offset,
      search_source_id: 'clks###',
      IsFetchDebug: false
    };

    const response = await axios.get(
      this.buildURL('/i18n_novel/search/page/v1/', params),
      { headers: this.config.headers }
    );

    return this.normalizeSearch(response.data);
  }

  async getDetail(seriesId) {
    const params = this.buildCommonParams();
    
    const data = {
      biz_param: {
        detail_page_version: 0,
        from_video_id: '',
        need_all_video_definition: false,
        source: 4,
        use_os_player: false,
        video_id_type: 1
      },
      series_id: seriesId
    };

    const response = await axios.post(
      this.buildURL('/novel/player/video_detail/v1/', params),
      data,
      { headers: this.config.headers }
    );

    return this.normalizeDetail(response.data);
  }

  async getEpisodes(seriesId) {
    const detail = await this.getDetail(seriesId);
    return detail.episodes || [];
  }

  async getWatchInfo(videoId) {
    const params = this.buildCommonParams();
    
    const data = {
      biz_param: {
        detail_page_version: 0,
        device_level: 3,
        need_all_video_definition: true,
        source: 4,
        use_os_player: false,
        video_id_type: 0,
        video_platform: 3
      },
      video_id: videoId
    };

    const response = await axios.post(
      this.buildURL('/novel/player/video_model/v1/', params),
      data,
      { headers: this.config.headers }
    );

    return this.normalizeStream(response.data);
  }

  // Normalization methods
  normalizeForYou(raw) {
    const items = raw?.data?.novel_models || [];
    
    return {
      provider: this.name,
      items: items.map(item => this.normalizeDramaItem(item))
    };
  }

  normalizeFeed(raw) {
    const items = raw?.card_list || [];
    
    return {
      provider: this.name,
      items: items.map(item => this.normalizeDramaItem(item.novel_model || item))
    };
  }

  normalizeSearch(raw) {
    const items = raw?.data?.items || [];
    
    return {
      provider: this.name,
      total: raw?.data?.total || 0,
      items: items.map(item => ({
        id: item.search_source_book_id,
        title: item.title,
        cover: item.cover_url || item.vertical_cover_url,
        description: item.abstract,
        tags: item.category_labels || [],
        episodeCount: item.total_episode_count,
        provider: this.name
      }))
    };
  }

  normalizeDetail(raw) {
    const data = raw?.data || {};
    const episodes = data.video_info_list || [];
    
    return {
      provider: this.name,
      id: data.series_id,
      title: data.series_name,
      cover: data.cover_url,
      description: data.description || data.introduction,
      tags: data.tags || [],
      totalEpisodes: data.total_episode_count,
      episodes: episodes.map((ep, idx) => ({
        id: ep.vid,
        episodeNumber: ep.episode_index || idx + 1,
        title: ep.episode_name || `Episode ${ep.episode_index || idx + 1}`,
        duration: ep.duration,
        thumbnail: ep.cover_url,
        isLocked: ep.is_lock || false,
        provider: this.name
      }))
    };
  }

  normalizeStream(raw) {
    const data = raw?.data?.video_model || {};
    const playAddr = data.play_addr || {};
    
    return {
      provider: this.name,
      videoId: data.vid,
      streamURL: playAddr.url_list?.[0] || null,
      quality: data.quality_type,
      duration: data.duration,
      format: playAddr.file_cs
    };
  }

  normalizeDramaItem(item) {
    return {
      id: item.book_id,
      title: item.book_name,
      cover: item.cover_url || item.vertical_cover_url,
      description: item.abstract || item.introduction,
      tags: item.tags || [],
      episodeCount: item.episode_count || item.total_episode_count,
      playCount: item.play_count,
      provider: this.name
    };
  }
}
