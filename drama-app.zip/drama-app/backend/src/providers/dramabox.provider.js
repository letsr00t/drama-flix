// src/providers/dramabox.provider.js
import { BaseProvider } from './base.provider.js';
import axios from 'axios';
import crypto from 'crypto';

export class DramaBoxProvider extends BaseProvider {
  constructor() {
    super({
      name: 'DramaBox',
      baseURL: 'https://api.dramaboxdb.com',
      
      config: {
        language: 'in',
        version: '470',
        timeout: 30000
      },
      
      capabilities: {
        hasForYou: true,
        hasTrending: true,
        hasLatest: true,
        hasSearch: true,
        hasDetail: true,
        hasStream: true,
        requiresAuth: true
      }
    });
    
    this.auth = null;
    this.deviceId = this.generateUUID();
  }

  generateUUID() {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, c => {
      const r = Math.random() * 16 | 0;
      const v = c === 'x' ? r : (r & 0x3 | 0x8);
      return v.toString(16);
    });
  }

  generateAndroidId() {
    return Array.from({ length: 16 }, () =>
      Math.floor(Math.random() * 16).toString(16)
    ).join('');
  }

  async generateToken() {
    const uuid = Math.floor(Math.random() * 1000000000);
    const timestamp = Date.now();
    
    const payload = {
      registerType: 'TEMP',
      userId: uuid
    };
    
    const token = Buffer.from(JSON.stringify(payload)).toString('base64');
    
    this.auth = {
      token: `Bearer ${token}`,
      deviceId: this.deviceId,
      androidId: this.generateAndroidId(),
      uuid,
      timestamp,
      expiry: timestamp + (24 * 60 * 60 * 1000)
    };
    
    return this.auth;
  }

  async ensureAuth() {
    if (!this.auth || Date.now() > this.auth.expiry) {
      await this.generateToken();
    }
  }

  buildHeaders() {
    const headers = {
      'Content-Type': 'application/json',
      'Accept': 'application/json',
      'User-Agent': 'DramaBox/4.7.0 Android',
      'Accept-Language': this.config.config.language
    };
    
    if (this.auth) {
      headers['Authorization'] = this.auth.token;
    }
    
    return headers;
  }

  buildParams(additionalParams = {}) {
    return {
      language: this.config.config.language,
      version: this.config.config.version,
      device_id: this.deviceId,
      timestamp: Date.now(),
      ...additionalParams
    };
  }

  // Note: This is a simplified implementation
  // Real DramaBox API might have different endpoints and structure
  // You need to verify with actual API traffic capture

  async getLatest(page = 1) {
    await this.ensureAuth();
    
    // Placeholder implementation
    // Replace with actual endpoint from traffic capture
    const params = this.buildParams({
      pageNo: page,
      pageSize: 20
    });
    
    try {
      const response = await axios.get(
        `${this.baseURL}/dramas/latest`,
        {
          params,
          headers: this.buildHeaders()
        }
      );
      
      return this.normalizeDramaList(response.data);
    } catch (error) {
      console.error('DramaBox getLatest error:', error.message);
      return { provider: this.name, items: [] };
    }
  }

  async getForYou(page = 1) {
    // Fallback to latest for now
    return this.getLatest(page);
  }

  async getTrending() {
    await this.ensureAuth();
    
    try {
      const response = await axios.get(
        `${this.baseURL}/dramas/trending`,
        { headers: this.buildHeaders() }
      );
      
      return this.normalizeDramaList(response.data);
    } catch (error) {
      console.error('DramaBox getTrending error:', error.message);
      return { provider: this.name, items: [] };
    }
  }

  async search(query, options = {}) {
    await this.ensureAuth();
    
    const { limit = 10, offset = 0 } = options;
    const params = this.buildParams({
      keyword: query,
      pageNo: Math.floor(offset / limit) + 1,
      pageSize: limit
    });
    
    try {
      const response = await axios.get(
        `${this.baseURL}/search`,
        {
          params,
          headers: this.buildHeaders()
        }
      );
      
      return this.normalizeSearch(response.data);
    } catch (error) {
      console.error('DramaBox search error:', error.message);
      return { provider: this.name, total: 0, items: [] };
    }
  }

  async getDetail(bookId) {
    await this.ensureAuth();
    
    try {
      const response = await axios.get(
        `${this.baseURL}/dramas/detail`,
        {
          params: this.buildParams({ bookId }),
          headers: this.buildHeaders()
        }
      );
      
      return this.normalizeDetail(response.data);
    } catch (error) {
      console.error('DramaBox getDetail error:', error.message);
      throw error;
    }
  }

  async getEpisodes(bookId) {
    await this.ensureAuth();
    
    try {
      const response = await axios.get(
        `${this.baseURL}/dramas/chapters`,
        {
          params: this.buildParams({ bookId }),
          headers: this.buildHeaders()
        }
      );
      
      return this.normalizeEpisodes(response.data);
    } catch (error) {
      console.error('DramaBox getEpisodes error:', error.message);
      return [];
    }
  }

  async getWatchInfo(bookId, episode) {
    await this.ensureAuth();
    
    try {
      const response = await axios.get(
        `${this.baseURL}/dramas/stream`,
        {
          params: this.buildParams({ bookId, episode }),
          headers: this.buildHeaders()
        }
      );
      
      return this.normalizeStream(response.data);
    } catch (error) {
      console.error('DramaBox getWatchInfo error:', error.message);
      throw error;
    }
  }

  // Normalization methods
  normalizeDramaList(raw) {
    const items = raw?.data?.results || raw?.results || [];
    
    return {
      provider: this.name,
      items: items.map(item => ({
        id: item.bookId,
        title: item.bookName,
        cover: item.cover,
        description: item.introduction,
        tags: item.tagV3s || [],
        episodeCount: item.chapterCount,
        playCount: item.playCount,
        provider: this.name
      }))
    };
  }

  normalizeSearch(raw) {
    const items = raw?.data?.book || [];
    
    return {
      provider: this.name,
      total: raw?.data?.total || 0,
      items: items.map(item => ({
        id: item.bookId,
        title: item.name,
        cover: item.cover,
        description: item.introduction,
        tags: item.tags || [],
        episodeCount: item.chapterCount,
        provider: this.name
      }))
    };
  }

  normalizeDetail(raw) {
    const data = raw?.data?.detail || raw?.data || {};
    
    return {
      provider: this.name,
      id: data.bookId,
      title: data.bookName,
      cover: data.cover,
      description: data.introduction,
      tags: data.tagV3s || [],
      totalEpisodes: data.chapterCount,
      episodes: []
    };
  }

  normalizeEpisodes(raw) {
    const chapters = raw?.data?.chapters || [];
    
    return chapters.map(ch => ({
      id: ch.chapterId,
      episodeNumber: ch.chapterIndex,
      title: ch.chapterName,
      duration: ch.duration,
      thumbnail: ch.cover,
      isLocked: ch.isLock || false,
      provider: this.name
    }));
  }

  normalizeStream(raw) {
    const video = raw?.data?.data?.chapter?.video || {};
    
    return {
      provider: this.name,
      streamURL: video.mp4 || video.m3u8,
      quality: video.quality || 'HD',
      format: video.mp4 ? 'mp4' : 'm3u8'
    };
  }
}
