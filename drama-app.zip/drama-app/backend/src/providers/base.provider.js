// src/providers/base.provider.js
import axios from 'axios';

export class BaseProvider {
  constructor(config) {
    this.name = config.name;
    this.baseURL = config.baseURL;
    this.config = config;
    this.axios = axios.create({
      timeout: config.timeout || 30000,
      headers: config.headers || {}
    });
  }

  // Core capabilities (to be implemented by subclasses)
  async getHome() {
    throw new Error('getHome() must be implemented');
  }

  async getForYou(page = 1) {
    throw new Error('getForYou() must be implemented');
  }

  async getTrending() {
    throw new Error('getTrending() must be implemented');
  }

  async getLatest() {
    throw new Error('getLatest() must be implemented');
  }

  async search(query, options = {}) {
    throw new Error('search() must be implemented');
  }

  async getDetail(id) {
    throw new Error('getDetail() must be implemented');
  }

  async getEpisodes(id) {
    throw new Error('getEpisodes() must be implemented');
  }

  async getWatchInfo(videoId) {
    throw new Error('getWatchInfo() must be implemented');
  }

  // Helper methods
  buildURL(path, params = {}) {
    const queryString = new URLSearchParams(params).toString();
    return `${this.baseURL}${path}${queryString ? '?' + queryString : ''}`;
  }

  generateSessionId() {
    const date = new Date();
    const dateStr = date.toISOString().slice(0, 10).replace(/-/g, '');
    const timeStr = date.toTimeString().slice(0, 8).replace(/:/g, '');
    const random = Math.random().toString(36).substring(2, 18).toUpperCase();
    return `${dateStr}${timeStr}${random}`;
  }

  normalizeResponse(raw, type) {
    return raw;
  }

  getCapabilities() {
    return this.config.capabilities || {};
  }

  getProviderInfo() {
    return {
      name: this.name,
      baseURL: this.baseURL,
      capabilities: this.getCapabilities()
    };
  }
}
