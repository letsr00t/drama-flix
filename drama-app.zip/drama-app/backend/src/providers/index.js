// src/providers/index.js
import { MeloLoProvider } from './melolo.provider.js';
import { DramaBoxProvider } from './dramabox.provider.js';

class ProviderRegistry {
  constructor() {
    this.providers = new Map();
    this.initialize();
  }

  initialize() {
    this.register('melolo', new MeloLoProvider());
    // DramaBox temporarily disabled - needs actual API endpoints
    // this.register('dramabox', new DramaBoxProvider());
  }

  register(name, provider) {
    this.providers.set(name.toLowerCase(), provider);
  }

  get(name) {
    const provider = this.providers.get(name.toLowerCase());
    if (!provider) {
      throw new Error(`Provider "${name}" not found`);
    }
    return provider;
  }

  list() {
    return Array.from(this.providers.keys());
  }

  getAll() {
    return Array.from(this.providers.entries()).map(([name, provider]) => ({
      name,
      capabilities: provider.getCapabilities(),
      info: provider.getProviderInfo()
    }));
  }

  async aggregateResults(method, ...args) {
    const results = await Promise.allSettled(
      Array.from(this.providers.values()).map(provider =>
        provider[method](...args)
      )
    );

    const successful = results
      .filter(r => r.status === 'fulfilled')
      .map(r => r.value);

    // Merge results from all providers
    const merged = {
      providers: successful.map(s => s.provider),
      items: successful.flatMap(s => s.items || [])
    };

    return merged;
  }
}

export const providerRegistry = new ProviderRegistry();
