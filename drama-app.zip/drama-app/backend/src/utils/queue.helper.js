// src/utils/queue.helper.js
class QueueHelper {
  constructor(concurrency = 5, interval = 1000) {
    this.concurrency = concurrency;
    this.interval = interval;
    this.queue = [];
    this.processing = 0;
    this.paused = false;
  }

  async add(fn) {
    return new Promise((resolve, reject) => {
      this.queue.push({ fn, resolve, reject });
      this.process();
    });
  }

  async process() {
    if (this.paused || this.processing >= this.concurrency || this.queue.length === 0) {
      return;
    }

    const task = this.queue.shift();
    if (!task) return;

    this.processing++;

    try {
      const result = await task.fn();
      task.resolve(result);
    } catch (error) {
      task.reject(error);
    } finally {
      this.processing--;
      setTimeout(() => this.process(), this.interval / this.concurrency);
    }
  }

  pause() {
    this.paused = true;
  }

  resume() {
    this.paused = false;
    this.process();
  }

  getStats() {
    return {
      queueLength: this.queue.length,
      processing: this.processing,
      paused: this.paused
    };
  }
}

export default QueueHelper;
