// src/utils/cache.helper.js
import NodeCache from 'node-cache';

class CacheHelper {
  constructor(ttl = 3600, checkPeriod = 600) {
    this.cache = new NodeCache({
      stdTTL: ttl,
      checkperiod: checkPeriod,
      useClones: false
    });
    
    this.stats = {
      hits: 0,
      misses: 0,
      sets: 0,
      deletes: 0
    };
  }

  get(key) {
    const value = this.cache.get(key);
    
    if (value !== undefined) {
      this.stats.hits++;
      return value;
    }
    
    this.stats.misses++;
    return null;
  }

  set(key, value, ttl) {
    this.stats.sets++;
    return this.cache.set(key, value, ttl);
  }

  delete(key) {
    this.stats.deletes++;
    return this.cache.del(key);
  }

  clear() {
    this.cache.flushAll();
  }

  getStats() {
    return {
      ...this.stats,
      keys: this.cache.keys().length,
      hitRate: this.stats.hits / (this.stats.hits + this.stats.misses) || 0
    };
  }

  has(key) {
    return this.cache.has(key);
  }
}

export default CacheHelper;
