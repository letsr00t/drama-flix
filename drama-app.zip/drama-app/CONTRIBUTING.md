# Contributing to DramaFlix

Thank you for your interest in contributing to DramaFlix! 🎬

## How to Contribute

### Reporting Bugs

Before creating bug reports, please check existing issues to avoid duplicates.

**Great Bug Reports include:**
- Clear, descriptive title
- Steps to reproduce
- Expected vs actual behavior
- Screenshots if applicable
- Environment details (OS, browser, Node version)

**Example:**
```
Title: Video player not working on Safari iOS

Description:
When clicking play on any episode, the video player shows
a black screen on Safari iOS 16.

Steps to Reproduce:
1. Open DramaFlix on Safari iOS 16
2. Navigate to any drama detail page
3. Click on a free episode
4. Click play button

Expected: Video should play
Actual: Black screen with loading spinner

Environment:
- Device: iPhone 13
- OS: iOS 16.3
- Browser: Safari 16.3
```

### Suggesting Features

We love feature suggestions! Please include:
- Clear use case
- Expected behavior
- Why this feature is valuable
- Any implementation ideas

### Pull Requests

1. **Fork the repository**
2. **Create a feature branch**
   ```bash
   git checkout -b feature/amazing-feature
   ```

3. **Make your changes**
   - Follow code style guidelines
   - Add tests if applicable
   - Update documentation

4. **Commit with clear messages**
   ```bash
   git commit -m "feat: add amazing feature"
   ```

   **Commit Convention:**
   - `feat:` New feature
   - `fix:` Bug fix
   - `docs:` Documentation changes
   - `style:` Code style changes (formatting)
   - `refactor:` Code refactoring
   - `test:` Adding tests
   - `chore:` Maintenance tasks

5. **Push to your fork**
   ```bash
   git push origin feature/amazing-feature
   ```

6. **Open a Pull Request**
   - Use clear title and description
   - Reference related issues
   - Include screenshots for UI changes

## Development Setup

### Prerequisites
- Node.js 16+ 
- npm or yarn
- Git

### Setup
```bash
# Clone your fork
git clone https://github.com/YOUR-USERNAME/dramaflix.git
cd dramaflix

# Add upstream remote
git remote add upstream https://github.com/ORIGINAL/dramaflix.git

# Backend setup
cd backend
npm install
cp .env.example .env
npm start

# Frontend setup (new terminal)
cd frontend
npm install
npm run dev
```

## Code Style Guidelines

### JavaScript/React

**Use ES6+ features:**
```javascript
// Good
const items = data.map(item => item.name);

// Avoid
var items = data.map(function(item) {
  return item.name;
});
```

**Use destructuring:**
```javascript
// Good
const { id, title, cover } = drama;

// Avoid
const id = drama.id;
const title = drama.title;
```

**Use async/await:**
```javascript
// Good
async function fetchData() {
  try {
    const result = await api.getData();
    return result;
  } catch (error) {
    console.error(error);
  }
}

// Avoid
function fetchData() {
  return api.getData()
    .then(result => result)
    .catch(error => console.error(error));
}
```

### React Components

**Use functional components:**
```javascript
// Good
function DramaCard({ drama }) {
  return <div>{drama.title}</div>;
}

// Avoid class components for new code
class DramaCard extends React.Component {
  render() {
    return <div>{this.props.drama.title}</div>;
  }
}
```

**Props destructuring:**
```javascript
// Good
function Component({ title, description }) {
  return <div>{title}</div>;
}

// Avoid
function Component(props) {
  return <div>{props.title}</div>;
}
```

### CSS

**Use meaningful class names:**
```css
/* Good */
.drama-card { }
.drama-card-title { }

/* Avoid */
.dc { }
.title { }
```

**Mobile-first approach:**
```css
/* Good */
.container {
  padding: 1rem;
}

@media (min-width: 768px) {
  .container {
    padding: 2rem;
  }
}
```

## Project Structure

### Adding New Provider

1. Create provider file:
```javascript
// backend/src/providers/newprovider.provider.js
import { BaseProvider } from './base.provider.js';

export class NewProviderProvider extends BaseProvider {
  constructor() {
    super({
      name: 'NewProvider',
      baseURL: 'https://api.newprovider.com',
      capabilities: { /* ... */ }
    });
  }

  async getForYou(page) {
    // Implementation
  }

  // Implement other required methods
}
```

2. Register provider:
```javascript
// backend/src/providers/index.js
import { NewProviderProvider } from './newprovider.provider.js';

// In initialize()
this.register('newprovider', new NewProviderProvider());
```

3. Test thoroughly!

### Adding New Component

1. Create component file:
```javascript
// frontend/src/components/NewComponent.jsx
import './NewComponent.css';

function NewComponent({ prop1, prop2 }) {
  return (
    <div className="new-component">
      {/* JSX */}
    </div>
  );
}

export default NewComponent;
```

2. Create styles:
```css
/* frontend/src/components/NewComponent.css */
.new-component {
  /* Styles */
}
```

3. Use in parent:
```javascript
import NewComponent from './components/NewComponent';

function Parent() {
  return <NewComponent prop1="value" />;
}
```

## Testing

### Before Submitting PR

**Backend:**
```bash
cd backend

# Test all endpoints
curl http://localhost:5000/api/health
curl http://localhost:5000/api/melolo/home
curl "http://localhost:5000/api/melolo/search?query=test"

# Check for errors in logs
```

**Frontend:**
```bash
cd frontend

# Build check
npm run build

# Manual testing
npm run dev
# Test all pages
# Test responsive design
# Check browser console for errors
```

### Test Checklist
- [ ] Code runs without errors
- [ ] No console errors/warnings
- [ ] Responsive on mobile
- [ ] Works in Chrome, Firefox, Safari
- [ ] No broken links
- [ ] Images load properly
- [ ] API calls work
- [ ] Error handling works

## Documentation

### Update README if you:
- Add new features
- Change configuration
- Modify setup process
- Add dependencies

### Update API.md if you:
- Add new endpoints
- Change response format
- Modify parameters

### Code Comments

**Do comment:**
- Complex logic
- Workarounds
- Important decisions

```javascript
// Workaround for iOS Safari video playback issue
// See: https://bugs.webkit.org/show_bug.cgi?id=123456
if (iOS) {
  player.load();
}
```

**Don't comment:**
- Obvious code
- What the code does (code should be self-explanatory)

```javascript
// Bad - obvious
// Set the title
setTitle(drama.title);

// Good - explains why
// Use fallback title for legacy dramas without title field
setTitle(drama.title || drama.name || 'Untitled');
```

## Review Process

### What We Look For

**Code Quality:**
- ✅ Clean, readable code
- ✅ Follows project conventions
- ✅ No unnecessary complexity
- ✅ Proper error handling

**Functionality:**
- ✅ Works as described
- ✅ No bugs introduced
- ✅ Edge cases handled
- ✅ Backward compatible

**Documentation:**
- ✅ Clear commit messages
- ✅ Updated README/API docs
- ✅ Code comments where needed
- ✅ PR description explains changes

### Review Timeline

- Initial review: Within 3-5 days
- Follow-up: Within 2 days
- Merge: After approval + CI passes

## Community Guidelines

### Be Respectful
- Treat everyone with respect
- Value different perspectives
- Be constructive in feedback
- Be patient with newcomers

### Be Professional
- Keep discussions on-topic
- No harassment or discrimination
- Respect maintainer decisions
- Follow code of conduct

## Getting Help

### Stuck on something?

1. **Check documentation:**
   - README.md
   - API.md
   - DEPLOYMENT.md

2. **Search existing issues:**
   - Someone might have solved it

3. **Ask in discussions:**
   - Explain what you tried
   - Share error messages
   - Provide context

4. **Create an issue:**
   - If it's a bug or feature request

## Recognition

Contributors will be:
- Listed in README.md
- Credited in release notes
- Acknowledged in commits

## License

By contributing, you agree that your contributions will be licensed under the same license as the project (MIT).

---

## Quick Reference

### Common Commands

```bash
# Start development
npm run dev

# Build for production  
npm run build

# Run tests
npm test

# Lint code
npm run lint

# Format code
npm run format
```

### Useful Links

- [Issues](https://github.com/project/issues)
- [Pull Requests](https://github.com/project/pulls)
- [Discussions](https://github.com/project/discussions)
- [Wiki](https://github.com/project/wiki)

---

**Thank you for contributing to DramaFlix! 🎉**
